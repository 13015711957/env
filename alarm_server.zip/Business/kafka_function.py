import os
import sys
import time
import traceback

from Core import conf
from Dao.r_data_center_dao import select_data_center

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from Business.get_kafka_data import get_event_final_result, get_alarm_final_result
from Business.send_kafka import send_alarm_data_sd, send_event_data_sd
from Dao.ai_alarminfo_dao import select_alarminfo_is_send
from Dao.ai_model_event_data_dao import select_model_event_data_by_eventid
from Dao.ai_model_event_dao import update_event_sendstate
from Dao.ai_alarminfo_dao import update_alarm_sendstate
# from Dao.t_monitor_dao import insert_monitor_alarm_data
from Dao.camera_dao import select_camera, select_device
from Dao.serverroom_dao import select_areacode
from Dao.dim_admincode_dao import select_provinfo

pre_pictureUrl = conf.get('urls', 'pre_pictureUrl')
pre_smallPic = conf.get('urls', 'pre_smallPic')
event_topic = conf.get('global', 'event_topic')
alarm_topic = conf.get('global', 'alarm_topic')


def alarm_map(alarmCode):
    AlarmMap = {
        11: '未授权',
        12: '身份未校验',
        21: '接触高危设备',
        22: '人员抽烟',
        23: '人员跌倒',
        24: '携带背包',
        31: '遗物置物',
        32: '机房长明灯',
        33: '火情告警',
    }
    return AlarmMap.get(alarmCode, None)


def topic_map(ProvinceId):
    TopicMap = {
        850: 'chongqing_roomwarm',

    }
    return TopicMap.get(ProvinceId, "综告云管")


class SentKafkaDate():

    @classmethod
    def sent_kafka(cls, r):
        if r is not None:
            event_id = r['event_id']
            original_data_id = r['original_data_id']
            alarmId = r['alarmId']
            alarmEventCategory = r['alarmEventCategory']
            alarmTime = r['alarmTime']
            alarmendTime = r['update_time']
            alarmType = r['alarmType']
            alarmSeverity = r['alarmSeverity']
            alarmRestored = r['alarmRestored']
            alarmConfirmOperator = r['alarmConfirmOperator']
            alarmClearOperator = r['alarmClearOperator']
            alarmCode = r['alarmCode']
            alarmCause = r['alarmCause']
            alarmCauseDesc = r['alarmCauseDesc']
            alarmAddition = r['alarmAddition']
            camera_id = r['camera_id']
            res = select_model_event_data_by_eventid(event_id)
            face_ids = []
            print(f'res:{res}')
            try:
                alarmTime = alarmTime.split('.')[0]
            except:
                pass
            for r in res:
                roomId = r['roomid']
                roomName = r['roomname']
                happenareaX = r['happenareax']
                happenareaY = r['happenareay']
                face_id = r['face_id']
                face_ids.append(face_id)
            try:
                province, city, provinceId = get_site(camera_id)
                # print(province, city, provinceId)
                station_info = select_data_center(roomId)
                stationName = station_info[0]['dc_name']
                stationId = station_info[0]['id']
                print(station_info)
            except BaseException as e:
                stationName = ''
                stationId = ''
                traceback.print_exc()
            try:
                device_info = select_device(camera_id)
                print(device_info)
                deviceId = device_info[0]['deviceId']
                deviceName = device_info[0]['name']
            except BaseException as e:
                deviceId = ''
                deviceName = ''
                traceback.print_exc()

                # 以告警类型区分 <0
            alarmCode = int(alarmCode)
            try:
                smallPic = pre_smallPic + str(alarmId)
            except:
                smallPic = ''
            if alarmCode < 0:
                cls.sent_event_kafka_data(alarmCode, original_data_id, event_id, alarmTime, alarmendTime,
                                          roomId, roomName, stationName, stationId, camera_id,
                                          deviceId, deviceName, happenareaX, happenareaY,
                                          face_ids, province, city, provinceId, smallPic)
            else:
                cls.sent_alarm_kafka_data(original_data_id, alarmId, alarmEventCategory, alarmTime, alarmendTime,
                                          alarmType, alarmSeverity, alarmRestored, alarmConfirmOperator,
                                          alarmClearOperator, alarmCode, alarmCause, alarmCauseDesc, alarmAddition,
                                          roomId, roomName, stationName, stationId, camera_id, deviceId, deviceName,
                                          happenareaX, happenareaY, face_ids, province, city, provinceId, smallPic)
            update_event_sendstate(1, event_id)
            update_alarm_sendstate(1, alarmId)

    @classmethod
    def check_table(cls):
        res = select_alarminfo_is_send()
        for r in res:
            if r is None:
                continue
            event_id = r['event_id']
            original_data_id = r['original_data_id']
            alarmId = r['alarmId']
            alarmEventCategory = r['alarmEventCategory']
            alarmTime = r['alarmTime']
            alarmType = r['alarmType']
            alarmSeverity = r['alarmSeverity']
            alarmRestored = r['alarmRestored']
            alarmConfirmOperator = r['alarmConfirmOperator']
            alarmClearOperator = r['alarmClearOperator']
            alarmCode = r['alarmCode']
            alarmCause = r['alarmCause']
            alarmCauseDesc = r['alarmCauseDesc']
            alarmAddition = r['alarmAddition']
            camera_id = r['camera_id']
            res = select_model_event_data_by_eventid(event_id)
            face_ids = []
            for r in res:
                roomId = r['roomId']
                roomName = r['roomName']
                happenareaX = r['happenareaX']
                happenareaY = r['happenareaY']
                face_id = r['face_id']
                face_ids.append(face_id)

            province, city, provinceId = get_site(camera_id)

            # 以告警类型区分 <0
            if alarmCode == 0:
                cls.sent_event_kafka_data(event_id, alarmTime, roomId, roomName, camera_id,
                                          happenareaX, happenareaY,
                                          face_ids, province, city, provinceId)
            else:
                cls.sent_alarm_kafka_data(original_data_id, alarmId, alarmEventCategory, alarmTime,
                                          alarmType, alarmSeverity, alarmRestored, alarmConfirmOperator,
                                          alarmClearOperator, alarmCode, alarmCause, alarmCauseDesc, alarmAddition,
                                          roomId, roomName, camera_id, happenareaX, happenareaY, face_ids, province,
                                          city, provinceId)
            update_event_sendstate(1, event_id)
            update_alarm_sendstate(1, alarmId)

    @classmethod
    def sent_event_kafka_data(cls, alarmCode, original_data_id, event_id, alarmTime, alarmendTime, roomId, roomName,
                              stationName, stationId, camera_id, deviceId, deviceName, happenareaX, happenareaY,
                              face_ids, province, city, provinceId, smallPic):

        pictureUrl = pre_pictureUrl + original_data_id
        data = get_event_final_result(str(event_id), 0, alarmTime, alarmendTime, 0, '', 0,
                                      0,
                                      roomId, roomName, stationName, stationId, province, city, camera_id, deviceId,
                                      deviceName,
                                      happenareaX, happenareaY, face_ids, pictureUrl, original_data_id, alarmCode,
                                      smallPic)
        # topic = topic_map(provinceId)
        topic = event_topic
        print(f'--topic--:{topic}')
        # if topic == '综告云管':
        #     send_event_data(data)
        # else:
        send_event_data_sd(data, topic)
        print(data)
        print('事件Kafka消息发送成功')

    @classmethod
    def sent_alarm_kafka_data(cls, original_data_id, alarm_id, alarmEventCategory, alarmTime, alarmendTime,
                              alarmType, alarmSeverity, alarmRestored, alarmConfirmOperator,
                              alarmClearOperator, alarmCode, alarmCause, alarmCauseDesc, alarmAddition,
                              roomId, roomName, stationName, stationId, camera_id, deviceId, deviceName,
                              happenareaX, happenareaY, face_ids, province, city, provinceId, smallPic):
        # alarm_monitor
        # alarmDesc = alarm_map(alarmCode)
        # insert_monitor_alarm_data(alarmCode, alarmDesc)
        alarm_config = {"pictureUrl": pre_pictureUrl}
        data = get_alarm_final_result(provinceId, alarm_config, original_data_id, str(alarm_id), alarmEventCategory,
                                      alarmTime,
                                      alarmendTime,
                                      alarmType, alarmSeverity,
                                      alarmRestored, alarmTime, alarmTime, alarmConfirmOperator,
                                      alarmClearOperator,
                                      alarmCode, alarmCause, alarmCauseDesc, alarmAddition, videoUrl='',
                                      roomId=roomId,
                                      roomName=roomName, stationName=stationName, stationId=stationId,
                                      province=province, city=city, cameraId=camera_id,
                                      deviceId=deviceId, deviceName=deviceName, happenareaX=happenareaX,
                                      happenareaY=happenareaY, face_ids=face_ids, smallPic=smallPic)
        # topic = topic_map(provinceId)
        topic = alarm_topic
        print(f'--topic--:{topic}')
        # if topic == '综告云管':
        #     send_alarm_data(data)
        # else:
        send_alarm_data_sd(data, topic)
        print(data)
        print('告警Kafka消息发送成功')


def get_site(camera_id):
    try:
        print(select_camera(camera_id)[0])
        roomid = select_camera(camera_id)[0]['roomid']
        areacode = select_areacode(roomid)[0]['areacode']
        prov_info = select_provinfo(areacode)
        province = prov_info[0]['province']
        city = prov_info[0]['city']
        provinceid = prov_info[0]['provinceid']
    except:
        province = ' '
        city = ' '
        provinceid = ''
    return province, city, provinceid


if __name__ == '__main__':
    while True:
        SentKafkaDate.check_table()
        time.sleep(10)
    # pass

# -*- coding:utf-8 -*-
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json
import cv2
import traceback
import requests
import datetime
from Business.stream_API.stream_monitor import StreamMonitor
from flask_restful import Resource, reqparse
from flask import jsonify


def get_qa_post_input_argument():

    parse = reqparse.RequestParser()
    parse.add_argument('Province', type=str)
    parse.add_argument('dcId ', type=str)
    parse.add_argument('roomName', type=str)
    parse.add_argument('roomNum', type=str)
    parse.add_argument('cameraNum', type=str)
    parse.add_argument('rtspUrl', type=str)
    parse.add_argument('action', type=str)
    return parse

class StreamAPI(Resource):

    def __init__(self):
        self.parser = get_qa_post_input_argument()
        self.args = self.parser.parse_args()


    def post(self, **kwargs):
        room_name = self.args['roomName']
        room_num = self.args['roomNum']
        camera_id = self.args['cameraNum']
        url = self.args['rtspUrl']
        action = self.args['action']

        print('args:',self.args)

        if camera_id is None or url is None:
            message = '服务必填参数缺失'
            return jsonify({'code': 0, 'info': message})

        state = -1

        
        try:

            if int(action) == 1:
                state = StreamMonitor.add_source(camera_id,url)

            if int(action) == 0:
                #datas = str(json.dumps({"source_id":camera_id}))
                state = StreamMonitor.del_source(camera_id)
            if state:
                return jsonify({
                    "code": 0,
                    "info": "Fail"
                })

            return jsonify({
                "code": 1,
                "info": 'Success'
            })
        except Exception as e:
            traceback.print_exc()
            print("Fail:", e)
            return jsonify({
                "code": 0,
                "info": str(e)
            })


def get_bk_post_input_argument():

    parse = reqparse.RequestParser()
    parse.add_argument('source_id',type=str)

    return parse

class SourceBreakAPI(Resource):

    def __init__(self):
        self.parser = get_bk_post_input_argument()
        self.args = dict(self.parser.parse_args())

    def post(self, **kwargs):
        try:
            camera_id = self.args['source_id']
            print(camera_id)
            # 调用类delete source
            StreamMonitor.source_del(camera_id)
        except Exception as e:
            traceback.print_exc()
            print("Fail:", e)
            return jsonify({
                "info": "Fail"
            })
        return jsonify({
            "info": "Success"
        })


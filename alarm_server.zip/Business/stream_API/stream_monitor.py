import os
import sys
import base64

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import cv2
import requests
import json
import traceback
from datetime import datetime, timedelta

import random
from Dao.t_stream_monitor_dao import insert_stream_monitor
import time
import uuid
from Dao.aisp_task_dao import insert_aisp_task_data
from Dao.camera_dao import get_camera_map, select_camera_zhiwu_pic, select_camera_warning_area
from util.iou_util import list_of_groups
with open('/project/jz.png', 'rb') as f:
    img_data = base64.b64encode(f.read())
    img_data = str(img_data, 'utf-8')
from Core import conf

alarm_url = conf.get('urls', 'alarm_url')
task_create_url = conf.get('urls', 'task_create_url')
task_delete_url = conf.get('urls', 'task_delete_url')
search_task_url = conf.get('urls', 'search_task_url')


class StreamState():

    def __init__(self):
        self.camera_state_dict = {}
        self.ds_camera_dict = {}

    def get_camera_state(self, camera_id):
        if self.camera_state_dict.get(camera_id, 0):
            return self.camera_state_dict[camera_id]
        return 0


stream_obj = StreamState()

FACE_MONITOR = '2002010'  # 人脸布控
ACCESS_DISCERN = '2002015'  # 进出识别
AREA_INTRUSION = '2002014'  # 区域入侵
RISK_DISCERN = '2002001'  # 危险行为识别(抽烟、持刀持械、未带口罩)
FIRE_DISCERN = '2002002'  # 危险事件(火焰)
PERSON_STAY = '2002011'  # 接触高危
AREA_COUNT = '2002007'  # 区域人数统计
FLOW_STATISTICS = '2002006'  # 客流统计
PERSON_FALL = '2002005'  # 人员跌倒
BACKPACK = '2002023'  # 背包
ZHIWU = '2002024'  # 置物
CARRY = '2002025'  # 搬出设备
LONG_LIGHT = '2002040'  # 长明灯
DOOR = '2002038'  # 人脸门禁
STAY_PASS = '2002042'  # 经过停留
HELMET = '2002041'  # 安全帽

# 打架斗殴


alarm_algorithm_map = {
    '-1': DOOR,
    '11': DOOR,
    '12': DOOR,
    '21': PERSON_STAY,
    '-2': STAY_PASS,
    '-3': STAY_PASS,
    '22': RISK_DISCERN,
    '23': PERSON_FALL,
    '24': BACKPACK,
    '25': CARRY,
    '26': HELMET,
    '31': ZHIWU,
    '32': LONG_LIGHT,
    '33': FIRE_DISCERN,

}


# ac = AsynClient()

class TaskData():

    def __init__(self):
        self.cameraId_taskId_map = {}
        self.camera_map = get_camera_map()

    def CreateData(self, message, event_type):

        rtsp_url = message["url"]
        camera_id = message["camera_id"]
        camera_uri = rtsp_url
        taskId = str(uuid.uuid1())
        if TaskObj.cameraId_taskId_map.get(camera_id, -1) == -1:
            TaskObj.cameraId_taskId_map[camera_id] = []
        TaskObj.cameraId_taskId_map[camera_id].append(taskId)
        print(TaskObj.cameraId_taskId_map[camera_id])
        if event_type == RISK_DISCERN:
            event_config = {'warning_type_list': ['3001', ]}
        elif event_type == FIRE_DISCERN:
            event_config = {'warning_type_list': ['3101']}
        elif event_type == CARRY:
            event_config = {'warning_type_list': ['4001', '4002']}
        elif event_type == PERSON_STAY:
            try:
                WR = select_camera_warning_area(camera_id)[0]['warning_area']
                warning_area = eval(WR)
                warning_area = list(map(int, warning_area))
                warning_area = list_of_groups(warning_area, 2)
            except:
                warning_area = [[0, 0], [0, 0], [0, 0], [0, 0]]

            warning_area_list = [{"x": point[0], "y": point[1]} for point in warning_area]
            event_config = {"cameraId": camera_id,
                            "warning_area_list": warning_area_list, "warning_stay_time": 30}
        elif event_type == STAY_PASS:
            event_config = {
                "warning_stay_time": 30
            }
        elif event_type == DOOR:
            event_config = {'group_name': 'JX_JiFang',
                            'alarm_filed': [0, 1, 2]}
        elif event_type == ZHIWU:
            model_picture_url = select_camera_zhiwu_pic(camera_id)[0]['model_picture_url']
            model_picture_url = model_picture_url.split('base64,')[-1]
            event_config = {'imgb64': model_picture_url}
        else:
            event_config = {}
        data = {
            "userId": "7",
            "secretId": "123456",
            "Timestamp": str(int(time.time())),
            "seqid": taskId,
            "taskId": taskId,
            "event_type": event_type,
            "strategy": -1,
            "result_receiver": {
                "Type": "HTTP",
                "uri": alarm_url,
                "method": "post",
            },
            "event_define_massage": ["event message"],
            # "alarm_start_time": "2020-08-20 08:00:00",
            # "alarm_end_time": "2022-08-20 20:59:59",
            "camera_type": "FILE",
            "cameraId_list": [
                {
                    "camera_id": camera_id,
                    "camera_uri": rtsp_url
                }
            ],
            "event_config": event_config,
            "alarm_strategy": 0,
            "alarm_rate": 10,
            "track_strategy": "FINISH"
        }
        print(data)
        insert_aisp_task_data(camera_id, rtsp_url, taskId, event_type, "Create")
        return data

    def DeleteData(self, message, taskId):
        camera_id = message["camera_id"]
        data = {
            "userId": "7",
            "secretId": "123456",
            "Timestamp": str(int(time.time())),
            "seqid": taskId,
            "taskId": taskId
        }
        print(data)
        insert_aisp_task_data(camera_id, "", taskId, "", "Delete")
        return data


TaskObj = TaskData()


class TaskManage():

    @classmethod
    def task_create(cls, message):
        Alarm_list = message.get("Alarm_list", [])
        Alarm_list = Alarm_list.split(';')
        Algorithms = []
        for AlarmCode in Alarm_list:
            Algorithm = alarm_algorithm_map.get(AlarmCode, '')
            if Algorithm and Algorithm not in Algorithms:
                Algorithms.append(Algorithm)
        print(Algorithms)
        success_list = []
        fail_list = []
        for i in range(len(Algorithms)):
            eventType = Algorithms[i]
            data = TaskObj.CreateData(message, eventType)
            r = requests.post(url=task_create_url, data=json.dumps(data))
            # r = await ac.post(url=task_create_url, data=json.dumps(data))
            print('任务创建结果:', r.text)
            res = json.loads(r.text)
            if res.get("flag") == 1:
                success_list.append({'taskId': data['taskId'], 'algorithm': eventType})
            else:
                fail_list.append({'taskId': data['taskId'], 'algorithm': eventType})
        return {'camera_id': message['camera_id'], 'success_list': success_list, 'fail_list': fail_list}

    @classmethod
    def task_delete(cls, message):
        camera_id = message["camera_id"]
        success_list = []
        fail_list = []
        for i in range(len(TaskObj.cameraId_taskId_map[camera_id])):
            taskId = TaskObj.cameraId_taskId_map[camera_id][0]
            TaskObj.cameraId_taskId_map[camera_id].remove(taskId)
            data = TaskObj.DeleteData(message, taskId)
            r = requests.post(url=task_delete_url, data=json.dumps(data))
            # r = await ac.post(url=task_delete_url, data=json.dumps(data))
            print('任务删除结果:', r.text)
            res = json.loads(r.text)
            if res.get("flag") == 1:
                success_list.append({'taskId': data['taskId']})
            else:
                fail_list.append({'taskId': data['taskId']})
        return {'camera_id': camera_id, 'success_list': success_list, 'fail_list': fail_list}

    @classmethod
    def task_query(cls, message):
        camera_id = message["camera_id"]
        for taskId in TaskObj.cameraId_taskId_map[camera_id]:
            data = {
                "userId": "7",
                "secretId": "123456",
                "Timestamp": str(int(time.time())),
                "seqid": taskId,
                "taskId": taskId
            }
            r = requests.post(url=search_task_url, data=json.dumps(data))
            print(r.text)


class StreamMonitor():

    def __init__(self):
        pass

    @classmethod
    def add_source(cls, camera_id, url):

        print(str(datetime.now().strftime("%H-%M-%S")))

        insert_stream_monitor(camera_id, -1, 'ADD', -1)  # 插入数据库 启流

        TaskObj.camera_map = get_camera_map()
        Alarm_list = TaskObj.camera_map.get(camera_id, "")
        print(f'camera_id:{camera_id}, Alarm_list:{Alarm_list}')

        if Alarm_list:
            # 接入AI视频通用框架 创建任务
            message = {"camera_id": camera_id, "url": url, "Alarm_list": Alarm_list, "now_time": datetime.now()}
            res = cls.create_task(message)
            print(res)
        else:
            return ()

    @classmethod
    def del_source(cls, camera_id):
        try:
            # 接入AI视频通用框架 删除任务
            message = {"camera_id": camera_id}
            res = cls.delete_task(message)
            print(res)
            return False
            # TODO res
        except:
            traceback.print_exc()
            insert_stream_monitor(camera_id, 0, 'DEL', -1)
            return True

    @classmethod
    def create_task(cls, message):
        print("创建任务")
        # res = func_loop.run(TaskManage.task_create(message))
        res = TaskManage.task_create(message)
        print("创建任务结束:", res)
        return res

    @classmethod
    def delete_task(cls, message):
        print("删除任务")
        # res = func_loop.run(TaskManage.task_delete(message))
        res = TaskManage.task_delete(message)
        print("删除任务结束:", res)
        return res


if __name__ == '__main__':
    camera_id = '01679e82265b427c8b2a22ea5dff215b'
    # WR=select_camera_warning_area(camera_id)[0]['warning_area']
    # warning_area =  eval(WR)
    # print(warning_area,type(warning_area))
    # time.sleep(100000)
    # url = 'rtsp://10.143.165.50/easy/live/ch46'
    # url = 'file:///opt/wdnmd-02/total_20220420.mp4'
    # url = 'file:///opt/show_video/1.mp4'
    url = 'rtsp://10.142.156.170:554/p'

    StreamMonitor.add_source(camera_id, url)
    import time

    time.sleep(70)
    StreamMonitor.del_source(camera_id)
    # WR = select_camera_warning_area(camera_id)[0]['warning_area']
    # warning_area = eval(WR)
    # warning_area = list(map(int, warning_area))
    # print(warning_area)

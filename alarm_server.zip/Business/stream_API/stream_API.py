# -*- coding:utf-8 -*-
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
path = os.path.abspath(os.path.join(os.getcwd(), "../.."))
#sys.path.append(path)
#print(os.getcwd())

from Business.stream_API.app_resource_stream import StreamAPI,SourceBreakAPI
from flask import Flask
from flask_restful import Api

class Config(object):
    JSON_SORT_KEYS = False

app = Flask('main')
app.config.from_object(Config)
api = Api(app=app)

api.add_resource(StreamAPI, '/StreamAnalysis/rtspinfo')

api.add_resource(SourceBreakAPI,'/break_source')

if __name__ == '__main__':
     app.run(threaded=True, host='0.0.0.0', port=17108)

import json
import os
import sys

from Dao.ai_model_event_dao import select_model_event

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'video_analysis'))



from Dao.ai_model_event_data_dao import instert_model_event_data, select_model_event_data
from Dao.camera_dao import select_cameraarea
from Dao.operator_info_dao import select_operator_info
from Dao.ai_original_data_detail_dao import select_ai_original_data_detail

"""camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
                           alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored,
                           alarmCause,alarmCauseDesc, alarmAddition"""

def int_to_str(target):
    if type(target) is str:
        return target
    if target is not None:
        result = str(target)
    else:
        result = ''
    return result

def str_to_int(target):

    if type(target) is int:
        return target
    if target is not None:
        try:
            result = int(target)
        except Exception as e:
            # traceback.print_exc()  ###
            return 0
    else:
        result = 0
    return result


def get_alarmData(original_data_id):

    alarmData_dic = select_ai_original_data_detail(original_data_id)
    print('alarmData_dic:', alarmData_dic)
    if alarmData_dic is not None:
        new_alarmData = []
        for alarmData in alarmData_dic:
            # print('alarmData:',alarmData)
            box = alarmData["box"]
            try:
                box = box.strip('[]').split()
                new_box = box[0] + box[2] + box[1] + box[3]
                # print('new_box:', new_box)
                # print('box:', type(new_box))
            except:
                new_box = ''

            dic = {
                "box": new_box,
                "label": alarmData['label'],
                "score": alarmData['scores']
            }

            new_alarmData.append(dic)
    else:
        new_alarmData = []
    return new_alarmData


"""缺少alarmId, alarmTime, alarmRestoreTime, alarmConfirmTime, videoUrl 
"""

def get_alarmInfo(alarm_config, original_data_id, alarmId, alarmEventCategory, alarmTime,alarmendTime, alarmType, alarmSeverity, alarmRestored,
                  alarmRestoreTime, alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmCode, alarmCause,
                  alarmCauseDesc, alarmAddition, videoUrl, alarmData,smallPic):

    alarmEventCategory = str_to_int(alarmEventCategory)
    alarmType = str_to_int(alarmType)
    alarmSeverity = str_to_int(alarmSeverity)
    alarmRestored = str_to_int(alarmRestored)
    alarmCode = str_to_int(alarmCode)

    pictureUrl = alarm_config.get("pictureUrl")
    pictureUrl = pictureUrl + original_data_id
    alarmInfo = {
        "alarmId": alarmId,
        "alarmEventCategory": alarmEventCategory,
        "alarmTime": alarmTime,
        "alarmendTime": alarmendTime,
        "alarmType": alarmType,
        "alarmSeverity": alarmSeverity,
        "alarmRestored": alarmRestored,
        "alarmRestoreTime": alarmRestoreTime,
        "alarmConfirmTime": alarmConfirmTime,
        "alarmConfirmOperator": alarmConfirmOperator,
        "alarmClearOperator": alarmClearOperator,
        "alarmCode": alarmCode,
        "alarmCause": alarmCause,
        "alarmCauseDesc": alarmCauseDesc,
        "alarmAddition": alarmAddition,
        "pictureUrl": pictureUrl,
        "smallPic": smallPic,
        "videoUrl": videoUrl,
        "alarmData": alarmData
    }
    return alarmInfo

def get_positionInfo(roomId, roomName, province, city, cameraId,deviceId,deviceName, happenareaX, happenareaY):
    # happenarea = select_cameraarea(cameraId)[0]["cameraarea"]
    happenarea = [480,-992.5,600,-942.5]

    positionInfo = {
        "roomId": roomId,
        "roomName": roomName,
        "deviceId":deviceId,
        "deviceName":deviceName,
        "province": province,
        "city": city,
        "cameraId": cameraId,
        "happenareaX": happenareaX,
        "happenareaY": happenareaY,
        "happenarea": happenarea
    }
    return positionInfo


def get_userInfo(face_ids):
    userInfo = []
    if len(face_ids) == 0:
        userInfo = []
    else:
        for operatorid in face_ids:
            result_select_operator_info = select_operator_info(operatorid)
            # print('result_select_operator_info:', result_select_operator_info)

            if len(result_select_operator_info) == 0:
                userInfo = []
            else:
                result_select_operator_info = result_select_operator_info[0]
                dic_select_operator_info = {"userId": result_select_operator_info["credentials_type"],
                                            "userName": result_select_operator_info["staff_name"],
                                            "phone": result_select_operator_info["tel"],
                                            "mail": result_select_operator_info["email"]}
                userinfo = dic_select_operator_info
                userInfo.append(userinfo)
    return userInfo


def get_alarm_final_result(provinceId, alarm_config, original_data_id, alarmId, alarmEventCategory, alarmTime,alarmendTime, alarmType, alarmSeverity,
                           alarmRestored, alarmRestoreTime, alarmConfirmTime, alarmConfirmOperator, alarmClearOperator,
                           alarmCode, alarmCause, alarmCauseDesc, alarmAddition, videoUrl, roomId, roomName,
                           stationName,stationId,province,
                           city, cameraId,deviceId,deviceName, happenareaX, happenareaY, face_ids,smallPic):

    alarmData = get_alarmData(original_data_id)
    alarmInfo = get_alarmInfo(alarm_config, original_data_id, alarmId, alarmEventCategory,
                  alarmTime,alarmendTime, alarmType, alarmSeverity,
                  alarmRestored,alarmRestoreTime, alarmConfirmTime, alarmConfirmOperator,
                  alarmClearOperator, alarmCode, alarmCause,
                  alarmCauseDesc, alarmAddition, videoUrl, alarmData,smallPic)
    positionInfo=get_positionInfo(roomId, roomName, province, city, cameraId,deviceId,deviceName, happenareaX, happenareaY)
    userInfo = get_userInfo(face_ids)

    alarm_final_result = {"Province":provinceId,
                          "stationName":stationName,
                          "stationId":stationId,
                     "alarmInfo": alarmInfo,
                     "positionInfo": positionInfo,
                     "userInfo": userInfo}

    print('----------get_alarm_final_result-------------')
    # print(alarm_final_result)
    return alarm_final_result

#######################事件消息##########################
def get_eventData(event_id):
    select_model_event_data_dic = select_model_event_data(event_id)
    eventData = []
    for model_event_data in select_model_event_data_dic:
        box = model_event_data["box"]
        try:

            box = box.strip('[]').split()
            new_box = box[0] + box[2] + box[1] + box[3]
        except:
            new_box = ''
        dic = {
            "box": new_box,
            "label": model_event_data['label'],
            "score": model_event_data['scores']
        }
        eventData.append(dic)

    return eventData

def get_eventInfo(eventId, eventType, eventTime,alarmendTime, eventClass, eventData, eventAddition,
                  eventStatus, eventName,pictureUrl,original_data_id,alarmCode,smallPic):
    try:
        eventType=select_model_event(eventId)[0]['event_code']
        # if alarmCode==-3 or alarmCode==-5 :
        #     eventType=alarmCode
    except:
        eventType=0
    eventType = str_to_int(eventType)
    eventClass = int_to_str(eventClass)
    eventName = int_to_str(eventName)
    eventStatus = str_to_int(eventStatus)

    eventInfo = {
        "eventId": eventId,
        "eventType": eventType,
        "eventTime": eventTime,
        "eventendTime": alarmendTime,
        "eventClass": eventClass,
        "eventName": eventName,
        "eventAddition": eventAddition,
        "eventStatus": eventStatus,
        "eventData": eventData,
        "pictureUrl":pictureUrl,
        "smallPic": smallPic,
    }
    return eventInfo

def get_event_final_result(eventId, eventType, eventTime,alarmendTime, eventClass, eventAddition, eventStatus, eventName,
                           roomId, roomName,stationName,stationId, province, city, cameraId,deviceId,deviceName,
                           happenareaX, happenareaY, face_ids,pictureUrl,original_data_id,alarmCode,smallPic):

    eventData = get_eventData(eventId)
    eventInfo = get_eventInfo(eventId, eventType, eventTime,alarmendTime, eventClass, eventData,
                              eventAddition, eventStatus, eventName,pictureUrl,original_data_id,
                              alarmCode,smallPic)
    positionInfo = get_positionInfo(roomId, roomName, province, city, cameraId,deviceId,deviceName, happenareaX, happenareaY)
    userInfo = get_userInfo(face_ids)
    event_final_result = {"eventInfo": eventInfo,
                          "stationName": stationName,
                          "stationId": stationId,
                          "positionInfo": positionInfo,
                          "userInfo": userInfo}
    print('---------get_event_final_result-----------')
    # print(event_final_result)
    return event_final_result

if __name__ == '__main__':

    original_data_id='5d59dd12-3933-11eb-83ae-a4bb6dca9770'##4b1e5782-4828-11eb-bb3a-a4bb6dca9770
    alarmId ="18088b9e-3dfe-11eb-b6dd-2c4d542d1a67"
    alarmEventCategory="1"#1
    alarmTime = "2020-12-14 19:20:50"
    alarmType= 1
    alarmSeverity= 3
    alarmRestored="1"#1
    alarmRestoreTime="2020-12-14 19:20:50"
    alarmConfirmTime="2020-12-14 19:20:50"
    alarmConfirmOperator=''
    alarmClearOperator="智能AI"
    alarmCode=0
    alarmCause=''
    alarmCauseDesc=''
    alarmAddition=''
    videoUrl=''
    # alarmData =get_alarmData(original_data_id)
    # print('alarmData:',alarmData)
    alarm_config = {"pictureUrl":"http://10.143.165.50:9081/room/viewpicture/getPicBase64?pictureId="}
    # alarmInfo=get_alarmInfo(alarm_config, original_data_id, alarmId, alarmEventCategory, alarmTime, alarmType, alarmSeverity,
    #               alarmRestored,
    #               alarmRestoreTime, alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmCode, alarmCause,
    #               alarmCauseDesc, alarmAddition, videoUrl, alarmData)
    roomId = "123"
    roomName = "北京123机房"
    province = "北京"
    city="北京市"
    cameraId ="01679e82265b427c8b2a22ea5dff216b"
    happenareaX = "54"
    happenareaY = "63"
    # positionInfo=get_positionInfo(roomId, roomName, province, city, cameraId, happenareaX, happenareaY)
    face_ids =  ["testJL"]
    # userInfo =get_userInfo(face_ids)
    alarm_final_result = get_alarm_final_result(alarm_config, original_data_id, alarmId, alarmEventCategory, alarmTime, alarmType, alarmSeverity,
                           alarmRestored, alarmRestoreTime, alarmConfirmTime, alarmConfirmOperator, alarmClearOperator,
                           alarmCode, alarmCause, alarmCauseDesc, alarmAddition, videoUrl, roomId, roomName,
                           province, city, cameraId, happenareaX, happenareaY, face_ids)
    print('alarm_final_result:',alarm_final_result)
    # print(type(alarm_final_result))

    event_id = '6b7d437e-4828-11eb-bce2-80fa5b677d77'
    # eventData = get_eventData(event_id)
    # print('eventData',eventData)
    eventType =  0
    eventClass = "0"
    eventName = 1#"1"
    eventTime = '2020-12-27 17:46:40'
    eventAddition = ''
    eventStatus = "1"#1
    # eventInfo = get_eventInfo(event_id, eventType, eventTime, eventClass, eventData, eventAddition, eventStatus, eventName)

    event_final_result = get_event_final_result(event_id, eventType, eventTime, eventClass, eventAddition, eventStatus, eventName,
                           roomId, roomName, province, city, cameraId, happenareaX, happenareaY, face_ids)
    print('event_final_result', event_final_result)

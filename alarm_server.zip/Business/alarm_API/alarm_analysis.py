import os
import sys
from uuid import uuid4

import requests

from Core import conf

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import time
import json
import cv2
import numpy as np
import pandas as pd
import traceback
from datetime import datetime
from Business.kafka_function import SentKafkaDate
from Dao.ai_original_data_dao import insert_data_to_ai_original_data, update_data_to_ai_original_data
from Dao.ai_original_data_detail_dao import insert_data_to_ai_original_data_detail, \
    update_data_to_ai_original_data_detail
from Dao.ai_model_event_dao import instert_model_event, update_data_to_ai_model_event, update_event_code
from Dao.ai_model_event_data_dao import instert_model_event_data, update_data_to_ai_model_event_data
from Dao.ai_alarminfo_dao import instert_alarminfo_object_id, select_alarminfo_by_camera_and_object, update_alarminfo, \
    update_alarminfo_updatetime, select_alarminfo_for_light
from Dao.camera_dao import select_camera, select_camera_door_area, get_camera_map
from Dao.serverroom_dao import select_serverroom, select_areacode
from Dao.dim_admincode_dao import select_provinfo

from Dao.operator_info_row_dao import select_operator_info_row, select_operator_allow_info
from util.image_util import base64_to_array, array_to_base64, img_cut
from util.new_id import new_id

camera_map = get_camera_map()
auth_host = conf.get('auth_url', 'host')
auth_port = conf.get('auth_url', 'port')
auth_post = conf.get('auth_url', 'url_post')
save_path_pre = conf.get('global', 'save_path')
auth_url = 'http://' + auth_host + ':' + auth_port + auth_post
is_kafka = int(conf.get('global', 'is_kafka'))


class AlarmAnalysis():

    def __init__(self):
        pass

    def alarm_analysis(self, data):

        data = data["data"]
        taskId = data["taskId"]
        alarm_type = data["alarm_type"]
        alarm_time = data["alarm_time"]
        camera_id = data["camera_Id"]
        # print(taskId, alarm_type, alarm_time, camera_id)
        alarm_detail = data["alarm_detail"]
        image = data["image"]
        # print(image)
        print("*" * 60)
        print(alarm_type)
        # 告警：火焰2002002
        if alarm_type == '2002001':
            for object in alarm_detail:
                # print(object)
                alarm_action_type = object.get("alarm_action_type", -1)
                bbox = []
                object_image = object["object_image"]
                objectId = object["objectId"]
                # 插入告警或更新告警
                alarminfo = dict(camera_id=camera_id, bbox=bbox, score=0, alarm_time=alarm_time,
                                 alarm_type=alarm_type, object_image=object_image, image=image,
                                 eventType=alarm_action_type, objectId=objectId)
                self.create_alarm(alarminfo)
        # 事件：跌倒2002005  背包2002023 置物2002024 搬出2002025
        elif alarm_type in ['2002002', '2002005', '2002023', '2002024', '2002025', '2002041']:
            for object in alarm_detail:
                # print(object)
                eventType = object.get("eventType", -1)
                bbox = []
                # score = object["score"]
                object_image = object["object_image"]
                objectId = object["objectId"]
                personnel_id = object.get('personnel_id', None)
                # print(bbox, score, object_image[:10])
                # 插入告警或更新告警
                alarminfo = dict(camera_id=camera_id, bbox=bbox, score=0, alarm_time=alarm_time,
                                 alarm_type=alarm_type, object_image=object_image, image=image,
                                 eventType=eventType, objectId=objectId, personnel_id=personnel_id)
                self.create_alarm(alarminfo)

        # 长明灯2002040
        if alarm_type == '2002040':
            for object in alarm_detail:
                # print(object)
                is_longlight = object.get("is_longlight", False)
                if is_longlight:
                    print("开灯")
                    res = select_alarminfo_for_light(camera_id)
                    if len(res) == 0:
                        eventType = object.get("eventType", -1)
                        bbox = []
                        # score = object["score"]
                        object_image = object["object_image"]
                        # print(bbox, score, object_image[:10])
                        # 插入告警或更新告警
                        alarminfo = dict(camera_id=camera_id, bbox=bbox, score=0, alarm_time=alarm_time,
                                         alarm_type=alarm_type, object_image=object_image, image=image,
                                         eventType=eventType)
                        self.create_alarm(alarminfo)
        # 接触高危设备/
        if alarm_type == '2002011':  # 接触高危设备/
            for object in alarm_detail:
                # print(object)
                eventType = object.get("eventType", -1)
                bbox = object["bbox"]
                score = 0
                object_image = object["object_image"]
                objectId = object["objectId"]
                start_time = object["start_time"]
                end_time = object["end_time"]
                personnel_id = object.get('personnel_id', None)
                # 插入告警或更新告警
                alarminfo = dict(camera_id=camera_id, bbox=bbox, score=score, alarm_time=start_time,
                                 end_time=end_time,
                                 alarm_type=alarm_type, object_image=object_image, image=image,
                                 eventType=eventType, objectId=objectId, personnel_id=personnel_id)
                self.create_alarm(alarminfo)

        if alarm_type == '2002042':  # 有人经过/有人停留
            for object in alarm_detail:
                print(object)
                eventType = object.get("eventType", -1)
                bbox = object["bbox"]
                score = 0
                object_image = object["object_image"]
                objectId = object["objectId"]
                start_time = object["start_time"]
                end_time = object["end_time"]
                alarm_code = object["alarm_code"]
                event_code = object["event_code"]
                personnel_id = object.get('personnel_id', None)
                # 插入告警或更新告警
                alarminfo = dict(camera_id=camera_id, bbox=bbox, score=score, alarm_time=start_time,
                                 end_time=end_time, alarmCode=alarm_code, event_code=event_code,
                                 alarm_type=alarm_type, object_image=object_image, image=image,
                                 eventType=eventType, objectId=objectId, personnel_id=personnel_id)
                self.create_alarm(alarminfo)
        if alarm_type == '2002038':  # 门禁
            for object in alarm_detail:
                print(object)
                alarm_time = object["alarm_start_time"]
                end_time = object["alarm_end_time"]
                person_id = object["personId"]
                io_status = object["io_status"]
                alarmCode = object["event_code"]
                eventType = object.get("eventType", -1)
                bbox = object["body_bbox"]
                score = 0
                object_image = object["object_image"]
                objectId = object["objectId"]
                # person_id = '1ee9eb5946e4450a90a6c31cf5f944ab'
                # TODO 门禁权限确认，告警再分析
                if person_id != '-1' and person_id != '-2':
                    isauth = operator_auth(camera_id, person_id)
                    if isauth == '1':
                        alarmCode = -1
                    else:
                        alarmCode = 11

                # 插入告警或更新告警
                personnel_id = object.get('personnel_id', None)
                alarminfo = dict(camera_id=camera_id, bbox=bbox, score=score, alarm_time=alarm_time,
                                 alarm_type=alarm_type, object_image=object_image, image=image,
                                 eventType=eventType, end_time=end_time, person_id=person_id,
                                 event_code=io_status, alarmCode=alarmCode, objectId=objectId,
                                 personnel_id=personnel_id)
                self.create_alarm(alarminfo)

    def create_alarm(self, alarminfo):
        camera_id = alarminfo["camera_id"]
        print(f'camera_id:{camera_id}')
        # print(f'alarminfo:{alarminfo}')
        alarm_time = alarminfo["alarm_time"]
        end_time = alarminfo.get("end_time", alarm_time)
        box = alarminfo["bbox"]
        happenareaX, happenareaY, working_area = get_happenarea(camera_id)
        score = alarminfo["score"]
        cut_base64 = save_cut_img(alarminfo["object_image"], camera_id)
        address = save_img(alarminfo["image"], camera_id)
        event_type = alarminfo["eventType"]
        event_code = alarminfo.get("event_code", event_code_map(event_type))
        alarmCode = alarminfo.get("alarmCode", alarm_code_map(event_type))
        object_id = alarminfo.get("objectId", -1)
        personnel_id = alarminfo.get('personnel_id', None)
        if alarmCode != -2:
            personnel_id = None
        print(object_id)

        camera_map = get_camera_map()
        alarmCode_list = camera_map.get(camera_id, "")
        alarmCode_list = alarmCode_list.split(',')
        print(alarmCode, alarmCode_list)
        if str(alarmCode) not in alarmCode_list[0]:
            print('havvvvvvvvvvve')
            return
        # 查找历史告警，如果有则更新，如果没有则插入
        result = select_alarminfo_by_camera_and_object(camera_id, alarmCode, object_id, state=1)
        # print('告警查找结果', result, len(result))
        if result is not None and len(result) > 0:
            alarm_id = result[-1]["alarmid"]
            event_id = result[-1]["event_id"]
            original_data_id = result[-1]["original_data_id"]
            is_update = True
        else:
            event_id = str(new_id()) + "_" + str(camera_id[-4:-1])
            original_data_id = str(new_id()) + "_" + str(camera_id[-4:-1])
            is_update = False

        event_type = '0'  # '事件类型0：人员，1：设备 2:事务'
        event_class = '0'  # '事件种类0：门禁，1：行动管控，2：高危告警'
        algorithm = 0  # '算法类型0：门禁，1：工作区域¼2：高危区域'
        task_id = 0  # 不知道这个段表示什么，先全部都是0
        analysis_result = []
        # object_id = -1
        temp_id = -1
        data_type = 3
        label = 'person'
        person_id = alarminfo.get('person_id', '-1')
        if person_id == '-1':
            person_name = 'unknown'
        else:
            person_name = person_id
        print(select_camera(camera_id))
        roomId = select_camera(camera_id)[0]["roomid"]
        roomName = select_serverroom(roomId)[0]["name"]
        province, city = get_site(camera_id)

        res_original_detail = {'original_data_id': original_data_id, 'data_type': data_type, 'box': str(box),
                               'label': label,
                               'face_id': person_name, 'scores': score,
                               'create_time': alarm_time, 'base64': cut_base64,
                               'face_score': score}

        res_original = {'original_data_id': original_data_id, 'address': address,
                        'create_time': alarm_time, 'box': str(box)}

        res_event_detail = {'event_id': event_id, 'data_type': data_type, 'box': str(box), 'face_id': person_name,
                            'body_id': temp_id, 'label': label, 'scores': score, 'roomId': roomId, 'roomName': roomName,
                            'province': province, 'city': city, 'happenareaX': happenareaX, 'happenareaY': happenareaY}

        res_event = {'event_id': event_id, 'event_type': event_type, 'event_class': event_class,
                     'event_code': event_code, 'original_data_id': original_data_id, 'task_id': task_id,
                     'camera_id': camera_id, 'algorithm_type': algorithm,
                     'start_time': alarm_time,
                     'end_time': end_time}

        alarmType = 0  # '告警类型0：人员，1：设备'
        alarmEventCategory = 1  # '告警事件类型，（该告警因执行何种事件而产生）取值范围如下：1.告警、2.恢复、9.变更'
        alarmRestored = 2  # '告警已恢复??标示该条告警是否已恢复,取值范围：1-> 已恢复、2-> 未恢复'
        alarmAddition = "deepstream检测结果"
        alarmConfirmOperator = ''
        alarmClearOperator = "智能AI"

        if alarmCode == 23:
            # 人员跌倒
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '人员跌倒'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '人员跌倒'
        elif alarmCode == 22:
            # 人员吸烟
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '人员吸烟'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '人员吸烟'
            # return
        # elif alarmCode == 102:
        #     # 未带口罩
        #     alarmSeverity = 1
        #     alarmCause = '未带口罩'  # '告警发生原因??简短描述（标题中的描述）'
        #     alarmCauseDesc = '未带口罩'
        # elif alarmCode == 103:
        #     # 持刀持械
        #     alarmSeverity = 1
        #     alarmCause = '持刀持械'  # '告警发生原因??简短描述（标题中的描述）'
        #     alarmCauseDesc = '持刀持械'
        # elif alarmCode == -2:
        #     # 有人经过
        #     alarmSeverity = 0
        #     alarmCause = '有人经过'  # '告警发生原因??简短描述（标题中的描述）'
        #     alarmCauseDesc = '有人经过'
        elif alarmCode == 33:
            # 火情告警
            alarmSeverity = 1
            event_type = '2'
            alarmType = 2
            alarmCause = '火情告警'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '火情告警'
            # return
        elif alarmCode == 25:
            # 搬出设备
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '搬出设备'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '搬出设备'
            # return
        elif alarmCode == 24:
            # 背包
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '背包'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '背包'
            # return
        elif alarmCode == 26:
            # 背包
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '未佩戴安全帽'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '未佩戴安全帽'

        elif alarmCode == 21:
            # 接触高危设备/停留
            alarmSeverity = 2
            event_type = '2'
            alarmType = 2
            alarmCause = '接触高危设备'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '接触高危设备'
        elif alarmCode == 31:
            # 置物
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '置物'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '置物'
        elif alarmCode == 32:
            # 长明灯
            alarmSeverity = 4
            event_type = '2'
            alarmType = 2
            alarmCause = '长明灯'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '长明灯'
        elif alarmCode == -1:
            # 正常进入
            alarmSeverity = 0
            alarmCause = '正常进入'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '正常进入'
        elif alarmCode == -2:
            # 有人经过
            alarmSeverity = 0
            alarmCause = '有人经过'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '有人经过'
        elif alarmCode == -3:
            # 有人停留
            alarmSeverity = 0
            alarmCause = '有人停留'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '有人停留'

        elif alarmCode == 11:
            # 未授权
            alarmSeverity = 3
            alarmCause = '未授权'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '未授权'
        elif alarmCode == 12:
            # 身份未校验
            alarmSeverity = 4
            alarmCause = '身份未校验'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '身份未校验'
        elif alarmCode == 13:
            # 非法闯入
            alarmSeverity = 3
            alarmCause = '非法闯入'  # '告警发生原因??简短描述（标题中的描述）'
            alarmCauseDesc = '非法闯入'
        else:
            return

        if is_update:
            if event_code == -1:
                update_event_code(event_code, event_id)

        else:
            # 插入原始详表
            print('插入原始详表')
            insert_id = insert_data_to_ai_original_data_detail(res_original_detail)

            # 插入原始表
            print('插入原始表')
            insert_id = insert_data_to_ai_original_data(res_original)

            # 插入事件详表
            print('插入事件详表')
            instert_model_event_data(event_id, event_type, box, person_name, temp_id, label, score, roomId, roomName,
                                     province, city, happenareaX, happenareaY)

            # 插入事件表
            print('插入事件表')
            instert_model_event(event_id, event_type, event_class, event_code, original_data_id, task_id, camera_id,
                                algorithm, alarm_time, alarm_time, personnel_id=personnel_id)

            print('插入告警')
            alarm_id = instert_alarminfo_object_id(camera_id, event_id, original_data_id, alarmType, alarmSeverity,
                                                   alarmCode,
                                                   alarm_time,
                                                   alarmConfirmOperator, alarmClearOperator, alarmEventCategory,
                                                   alarmRestored,
                                                   alarmCause, alarmCauseDesc, alarmAddition, object_id, alarm_time,
                                                   state=1)
            update_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            if is_kafka:
                SentKafkaDate.sent_kafka(r=dict(event_id=event_id, original_data_id=original_data_id, alarmId=alarm_id,
                                                alarmEventCategory=alarmEventCategory, alarmTime=alarm_time,
                                                update_time=update_time, alarmType=alarmType,
                                                alarmSeverity=alarmSeverity, alarmRestored=alarmRestored,
                                                alarmConfirmOperator=alarmConfirmOperator,
                                                alarmClearOperator=alarmClearOperator, alarmCode=alarmCode,
                                                alarmCause=alarmCause,
                                                alarmCauseDesc=alarmCauseDesc, alarmAddition=alarmAddition,
                                                camera_id=camera_id))


def get_happenarea(camera_id):
    try:
        working_area = select_camera_door_area(camera_id)[0]["door_area"]
        working_area = json.loads(working_area)  # [x1,y1,x2,y2]
    except:
        working_area = [600, 100, 1050, 700]
    happenareaX = (float(working_area[0]) + float(working_area[2])) / 2
    happenareaY = (float(working_area[1]) + float(working_area[3])) / 2
    return happenareaX, happenareaY, working_area


def get_site(camera_id):
    roomid = select_camera(camera_id)[0]['roomid']
    print(roomid)
    areacode = select_areacode(roomid)[0]['areacode']
    print(areacode)
    prov_info = select_provinfo(areacode)
    province = prov_info[0]['province']
    city = prov_info[0]['city']
    return province, city


def Is_allowed_enter(face_id, camera_id):  # 判断人员进出权限
    try:
        roomid = select_camera(camera_id)[0]['roomid']
        r = select_operator_allow_info(face_id)
        print(r)
        for item in r:
            roomids = item.get('roomid', '')
            if roomid in roomids > 0:
                print('####查询到对应工单信息，允许进入机房')
                return True
        print('####未查询到对应工单信息，不允许进入机房')
        return False

    except:
        print("###判断进出权限失败")
        return True


def save_img(imgb64, camera_id):
    if imgb64:
        data = base64_to_array(imgb64)
        today = datetime.now().strftime('%Y-%m-%d')
        # t = int(time.time())
        t = uuid4()
        img_save_name = str(t) + '_' + camera_id[-4:] + '.png'
        save_path = os.path.join(save_path_pre, today)
        img_save_path = os.path.join(save_path, img_save_name)
        if not os.path.exists(save_path):
            print('####新建文件夹: ', save_path)
            os.makedirs(save_path)
        if data is not None:
            cv2.imwrite(img_save_path, data)
        print('img_save_path:', img_save_path)
        return img_save_path
    else:
        print('图片为空')


def save_cut_img(imgb64, camera_id):
    if imgb64:
        data = base64_to_array(imgb64)
        today = datetime.now().strftime('%Y-%m-%d')
        # t = int(time.time())
        t = uuid4()
        img_save_name = str(t) + '_' + camera_id[-4:] + '_cut.png'

        save_path = os.path.join(save_path_pre, today)
        img_save_path = os.path.join(save_path, img_save_name)
        if not os.path.exists(save_path):
            print('####新建文件夹: ', save_path)
            os.makedirs(save_path)
        if data is not None:
            cv2.imwrite(img_save_path, data)
        print('img_save_path:', img_save_path)
        return img_save_path
    else:
        print('图片为空')


def event_code_map(event_type):
    EventCodeMap = {
        "1004": -6,  # 人员跌倒
        "3001": -7,  # 人员吸烟
        # "3002" : -7,   # 持刀持械
        "3005": -7,  # 未带口罩
        "3101": -5,  # 火情告警
        "2002002": -5,
        "2002011": -4,  # 接触高危设备
        "2002023": -6,  # 背包
        "2002024": -5,  # 置物
        "2002025": -6,  # 搬出设备
        "2002040": -6,  # 长明灯
        "2002041": -7,  # 未戴安全帽
    }
    return EventCodeMap.get(event_type, None)


def alarm_code_map(event_type):
    AlarmCodeMap = {
        "1004": 23,  # 人员跌倒
        "3001": 22,  # 人员吸烟
        # "3002" : 103,   # 持刀持械
        "3005": 102,  # 未带口罩
        "3101": 33,  # 火情告警
        "2002002": 33,
        "2002011": 21,  # 接触高危设备
        "2002023": 24,  # 背包
        "2002024": 31,  # 置物
        "2002025": 25,  # 搬出设备
        "2002040": 32,  # 长明灯
        "2002041": 26,  # 未戴安全帽
    }
    return AlarmCodeMap.get(event_type, None)


Alarm = AlarmAnalysis()


def operator_auth(camera_id, operatorid):
    try:
        data = {
            'camera_id': camera_id,
            'operatorid': operatorid
        }
        r = requests.post(auth_url, json=data)
        r = json.loads(r.text)
        print(r)
        auth = r.get('data', {}).get('isauth', 0)
    except Exception as e:
        auth = 0
    return auth


if __name__ == '__main__':
    auth = operator_auth('01679e82265b427c8b2a22ea5dff221b', 'testZJG')
    print(auth)
    pass
    province, city = get_site('2b86cc3a-631e-11ec-b9dd-00ff862724fc')
    # Alarm.alarm_analysis(data)

    # print(res)

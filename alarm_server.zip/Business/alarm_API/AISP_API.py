import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import json
import cv2
import traceback
import requests
import datetime
from flask import Flask, request, jsonify
from Business.alarm_API.alarm_analysis import AlarmAnalysis,Alarm


app = Flask(__name__)
@app.route('/IMR_alarminfo', methods=['POST'])
def IMR_alarminfo():
    data = request.get_data()
    #print("data: ", data)
    data = json.loads(data)
    #print("data: ", data)
    #f = open('smoke_data.txt', mode='w')  # 打开文件，若文件不存在系统自动创建。 
    #f.write(str(data))  # write 写入
    #f.close()  # 关闭文件
    Alarm.alarm_analysis(data)
    return jsonify({
       "info": "Success"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=17109, threaded=True)


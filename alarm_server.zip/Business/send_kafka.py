# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  kafka_test2
@Desc   ：
==================================================
"""
from kafka import KafkaProducer
import json
import datetime

from Core import conf

kafka_ip = conf.get('global', 'kafka_ip')

class DateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime("%Y-%m-%d %H:%M:%S")
        else:
            return json.JSONEncoder.default(self, obj)


class ProducerUtils():
    def __init__(self, host):
        self.host = host
        self.producer = KafkaProducer(
            bootstrap_servers=[self.host],
            value_serializer=lambda m: json.dumps(m, cls=DateEncoder).encode(('utf-8')),
            #sasl_mechanism="SCRAM-SHA-512",
            #security_protocol='SASL_PLAINTEXT',
            #sasl_plain_username='fjsmartcr',
            #sasl_plain_password='21febc9c89df0046a92243d0497e3a80',
            acks='all',
            retries=1,

        )

    def send_data(self, topic_name, data, partition=None):
        if partition is not None:
            future = self.producer.send(topic_name, value=data, partition=partition)
        else:
            future = self.producer.send(topic_name, value=data)
        record_metadata = future.get(timeout=1000)
        print(record_metadata)
        return record_metadata



kafka_utils_jt = ProducerUtils(kafka_ip)


def send_alarm_data_sd(data, topic):
    # kafka_utils_sd.send_data(topic, data,0)
    kafka_utils_jt.send_data(topic, data, 0)


def send_event_data_sd(data, topic):
    # kafka_utils_sd.send_data(topic, data,0)
    kafka_utils_jt.send_data(topic, data, 0)


if __name__ == '__main__':
    a = ProducerUtils('134.224.185.18:9092')
    print("init success")
    ### 告警信息发送 ####
    data = {
        "alarmInfo": {
            "alarmId": "14aa57f4-59fe-11eb-80f6-6c92bf685ec8",
            "alarmEventCategory": 1,
            "alarmTime": "2021-01-19 10:28:56",
            "alarmType": 0,
            "alarmSeverity": 2,
            "alarmRestored": 2,
            "alarmRestoreTime": "2021-01-19 10:28:56",
            "alarmConfirmTime": "2021-01-19 10:31:56",
            "alarmConfirmOperator": '',
            "alarmClearOperator": "智能AI",
            "alarmCode": 1,
            "alarmCause": '跟人带人',
            "alarmCauseDesc": '213昌平机房沈阔跟人带人进入',
            "alarmAddition": '',
            "pictureUrl": "http://10.143.165.50:9081/room/viewpicture/getPicBase64?pictureId=fe325a04-4520-11eb-87ee-6c92bf685ec8",
            "videoUrl": "",
            "alarmData": [{
                "box": "14, 7, 93, 111",
                "label": 'person',
                "score": '0.9807567'}]
        },
        "positionInfo": {
            "roomId": "4086",
            "roomName": "213昌平机房",
            "province": "北京",
            "city": "北京市",
            "cameraId": "19",
            "happenareaX": "54",
            "happenareaY": "63",
            "happenarea": "门口区域",
        },
        "userInfo": [
            {
                "userId": "testCJ",
                "userName": "张三",
                "phone": "18812341234",
                "mail": "18812341234@163.com"
            },
            {
                "userId": "testSk",
                "userName": "沈阔",
                "phone": "18000004444",
                "mail": "SK@qq.com"
            }
        ]
    }
    a.send_data("alarmTopic", data)
    print("=====告警信息发送=====")
    data2 = {
        "eventInfo": {
            "eventId": "18088b9e-3dfe-11eb-b6dd-2c4d542d1a99",
            "eventType": 0,
            "eventTime": "2020-12-14 19:20:50",
            "eventClass": 0,
            "eventName": 1,
            "eventAddition": "",
            "eventStatus": 1,
            "eventData": [
                {
                    "box": "14,7,93,111",
                    "label": "person",
                    "score": 0.9807567
                }
            ]
        },
        "positionInfo": {
            "roomId": "123",
            "roomName": "北京999机房",
            "province": "北京",
            "city": "北京市",
            "cameraId": "20",
            "happenareaX": "54",
            "happenareaY": "63"
        },
        "userInfo": [
            {
                "userId": "7468CEFCC2FC02BAC24B269E7952F020",
                "userName": "健康1",
                "phone": "18812341234",
                "mail": "18812341234@163.com"
            },
            {
                "userId": "7468CEFCC2FC02BAC24B269E7952F021",
                "userName": "健康2",
                "phone": "18812341234",
                "mail": "18812341234@163.com"
            }
        ]
    }
    a.send_data("eventTopic", data)
    print("======事件信息发送=====")

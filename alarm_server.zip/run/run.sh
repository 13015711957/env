#!/bin/bash

now=`date "+%Y%m%d"`

PY_CMD='python'
UVICORN_CMD='uvicorn'
ALARM_DIR='/project/Business/alarm_API'
STREAM_DIR='/project/Business/stream_API'
BASE_DIR='/project'
start()
{

    cd ${ALARM_DIR}
    ($PY_CMD -u AISP_API.py &>../../log/AISP_API_${now}.log &)
    cd ${STREAM_DIR}
    ($PY_CMD -u stream_API.py &>../../log/stream_API_${now}.log &)
    cd ${BASE_DIR}
    ($PY_CMD -u update_state.py &>log/update_state_${now}.log &)

}

kill_keywork_process()
{
  key_work=$1
  for t_pid in `ps xf|grep -E ${key_work} |grep -v grep|awk '{print $1}'`
  do
    kill -9 ${t_pid}
  done
}

stop()
{
    list='AISP_API update_state stream_API '
    for t in $list
    do
        kill_keywork_process $t
    done

    cd - &>/dev/null
}

restart_api()
{
  stop
  sleep 1
  start_api
}

restart()
{
  stop
  sleep 1
  start
}


case "$1" in
  start_api)
    start_api
    ;;
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart_api)
    restart_api
    ;;
  restart)
    restart
    ;;
  *)
    echo $"Usage: $0 {start|stop|restart}"
    exit 2
esac

exit $?


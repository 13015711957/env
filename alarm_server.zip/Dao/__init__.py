# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: __init__.py
@Author  :linych 
@Time    :2020/11/26 14:42
@Desc  : 
'''
from Core import db_util
from datetime import datetime


def update_person_info(person_id, sex=None, age=None, face_image_uri=None, person_image_uri=None):
    try:
        db_util.check_connect()
        if face_image_uri:
            sql = "update t_person_info set face_image_uri='%s' where person_id='%s'" % \
                  (face_image_uri, person_id)
            db_util.dml(sql)
        if person_image_uri:
            sql = "update t_person_info set person_image_uri='%s' where person_id='%s'" % \
                  (person_image_uri, person_id)
            db_util.dml(sql)
        if (sex is not None) and (age is not None):
            sql = "update t_person_info set sex='%s', age='%s' where person_id='%s'" % (sex, age, person_id)
            db_util.dml(sql)
    except Exception as e:
        import traceback
        traceback.print_exc()
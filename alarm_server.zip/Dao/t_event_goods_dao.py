# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_event_goods_dao
@Time    : 2021/5/21 18:09
@Author  : chenych
@Desc    :
"""

import time
from Core import db_util


def insert_event_goods(event_id, goods_id):
    if goods_id is None:
        goods_id = 0
    sql = 'INSERT INTO  t_event_goods(event_id,goods_id,create_time,defun_ind)'
    sql += ' VALUES("%s","%s","%s",0)' % (event_id,
                                          goods_id,
                                          time.strftime('%Y-%m-%d %H:%M:%S'))

    db_util.dml(sql)

# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_live_conf_dao
@Time    : 2021/5/26 18:16
@Author  : chenych
@Desc    :
"""

from Core import db_util


def get_all_live_conf():
    sql = 'SELECT camera_id,rtmp_url,size,fps FROM t_live_conf WHERE defun_ind=0'
    ret = db_util.query(sql, 'all_dict')
    
    return ret

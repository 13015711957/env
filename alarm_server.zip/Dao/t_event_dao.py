# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_event_dao
@Time    : 2021/5/20 15:34
@Author  : chenych
@Desc    :
"""
from Core import db_util
import time


def insert_event(event_data):
    sql = 'insert into t_event(event_type, event_time, event_status, create_time, defun_ind, image_id, image_uri)'
    sql += ' values("%s","%s","%s","%s","%s","%s","%s")' % (event_data['event_type'],
                                                            event_data['event_time'],
                                                            event_data['event_status'],
                                                            time.strftime('%Y-%m-%d %H:%M:%S'),
                                                            0, event_data['image_id'],
                                                            event_data['image_uri'])
    ins_id = db_util.dml(sql)
    return ins_id

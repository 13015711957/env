# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：video_analysis
@File   :  ai_original_data_detail_dao
@Desc   ：
==================================================
"""
import base64
import numpy as np
import cv2
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from Core import imr_db_util
from datetime import datetime

def update_base64(original_data_id,imgb64):
    imr_db_util.check_reconnect()
    sql="update ai_original_data_detail set base64='{}' where original_data_id='{}'".format(imgb64,original_data_id)
    print(sql)
    res = imr_db_util.dml(sql)
    return res

def array_to_base64(img_array):
    retval, buffer = cv2.imencode('.jpg', img_array)
    pic_str = base64.b64encode(buffer)
    pic_str = pic_str.decode()
    return pic_str


if __name__=='__main__':
    f = open('ay.txt', 'r')
    imgb64 = f.read()
    #address = 'gr.jpg'
    #address = 'gw.jpg'
    #address = 'gzqy.jpg'
    #address = 'aqm.jpg'
    #address = 'gzf.jpg'
    #address = 'jyj.jpg'
    #img_path = address
    #img_array = cv2.imread(img_path)
    #imgb64 = array_to_base64(img_array)

    #original_data_id = '8bed78b2-dad9-11eb-a12c-6c92bf685ec8'
    #original_data_id = '665b78f6-4b73-11eb-828b-6c92bf685ec8'
    #original_data_id = '9fb2e596-4b30-11eb-8a63-6c92bf685ec8'
    #original_data_id = '019c98d0-c5a0-11eb-93ff-6c92bf685ec8'
    #original_data_id = '036b635c-770e-11eb-b5cc-6c92bf685ec8'
    original_data_id = '8e66ae7a-6331-11ec-bb72-6c92bf685ec8_221_9'
    original_data_id = '91098980-9eba-11ec-adb6-6c92bf6864f6_221'
    update_base64(original_data_id,imgb64)


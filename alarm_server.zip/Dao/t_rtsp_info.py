from Core import db_util
from datetime import datetime

def insert_rtsp_info(room_name, room_num, camera_id, url, action, now, state):
    try:
        db_util.check_connect()
        sql = "insert into t_rtsp_info (roomName, roomNum, camera_id, rtsp_url, action, create_time, state) " \
              "VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}')".format(room_name, room_num, camera_id, url,
                                                                         action, now, state)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()
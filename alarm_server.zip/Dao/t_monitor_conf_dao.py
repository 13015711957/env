# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_monitor_conf_dao
@Time    : 2021/5/24 18:33
@Author  : chenych
@Desc    :
"""

from Core import db_util


def get_all_bbox(event_type=None):
    if event_type is None:
        sql = 'SELECT area_id,cid,camera_id,bbox FROM t_monitor_conf WHERE defun_ind=0'
    else:
        sql = 'SELECT area_id,cid,camera_id,bbox FROM t_monitor_conf WHERE defun_ind=0 AND event_type="%s"'%(event_type)
    res = db_util.query(sql, 'all_dict')

    return res



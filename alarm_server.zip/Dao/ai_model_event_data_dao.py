# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  ai_model_event_data_dao
@Desc   ：
==================================================
"""
import sys
import os

from datetime import datetime
import traceback

from Core import imr_db_util
from util.new_id import new_id

def select_model_event_data(event_id):
    imr_db_util.check_reconnect()
    sql = """
            select event_id, data_type, box, face_id, label, scores, create_time,roomId, roomName,
             province, city, happenareaX, happenareaY from ai_model_event_data where event_id = '%s' """ % event_id
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def instert_model_event_data(event_id, data_type, box, face_id, body_id, label, scores, roomId, roomName, province, city, happenareaX, happenareaY):

    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    imr_db_util.check_reconnect()
    sql = """
            insert into ai_model_event_data (event_id, data_type, box, face_id, body_id, label, scores, create_time, roomId, roomName, province, city, happenareaX, happenareaY) values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s') returning event_id
        """ % (event_id, data_type, box, face_id, body_id, label, scores, now_str, roomId, roomName, province, city, happenareaX, happenareaY)
    # print('------instert_model_event_data_sql------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        traceback.print_exc()
    return event_id

def select_model_event_data_by_eventid(event_id):
    imr_db_util.check_reconnect()
    sql = """ select roomId, roomName, province, city, happenareaX, happenareaY, face_id from ai_model_event_data where event_id = '%s' """ % event_id
    # print('=======select_model_event_data_by_eventid========')
    print(sql)
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_temp_id_by_roomId(roomId):
    imr_db_util.check_reconnect()
    ####样例sql  select top 1 * from MyTable Order By ModifyTime Desc 查询最近的一条语句
    sql = """
                    select body_id from ai_model_event_data where roomId = '%s' and create_time>=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY create_time desc limit 1 """ % roomId
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


def update_model_event_data_face_id(event_id,prob_object):
    imr_db_util.check_reconnect()
    sql = """update ai_model_event_data set face_id='%s' where event_id='%s' limit 1 """%(prob_object,event_id)
    result=imr_db_util.dml(sql.strip())
    return result

def update_eventinfo_detail(event_id, face_id, box):
    imr_db_util.check_reconnect()
    sql = """update ai_model_event_data set face_id='%s' and box='%s' where event_id='%s' """%(face_id, box, event_id)
    result=imr_db_util.dml(sql.strip())
    return result

def update_data_to_ai_model_event_data(res,event_id):
    imr_db_util.check_reconnect()
    tb = 'ai_model_event_data'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'update %s' % tb + ' set ' + ','.join(['%s'%str(i[0])+'='+ str(repr(i[1])) for i in lis]) + " where event_id = '%s';" % event_id
    print(sentence)
    insert_id = imr_db_util.dml(sentence)
    return insert_id

if __name__ == '__main__':
    event_id = 'dfdd1552-5616-11eb-8c85-80fa5b677d77'
    r = select_model_event_data_by_eventid(event_id)
    print(r)


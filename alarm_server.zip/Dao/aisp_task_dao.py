from Core import db_util
from datetime import datetime
import traceback

def insert_aisp_task_data(camera_id, url, taskId, event_type, action):
    db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql='''
          insert into aisp_task (camera_id, url, taskid, event_type, action, create_time) values ('%s','%s','%s','%s','%s','%s') returning taskid
        '''%(camera_id, url, taskId, event_type, action, now_str)
    print(sql)
    try:
        prefecture_df = db_util.dml(sql.strip())
    except:
        traceback.print_exc()


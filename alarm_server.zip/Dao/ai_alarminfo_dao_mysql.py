# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  ai_alarminfo_dao
@Desc   ：
==================================================
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime
import traceback

from Core import imr_db_util
from util.new_id import new_id


def delete_alarminfo(alarmId):
    imr_db_util.check_reconnect()
    sql = "delete from ai_alarminfo where alarmId = '{}'".format(alarmId)
    res = imr_db_util.dml(sql)
    return res

def select_alarminfo_is_send():
    imr_db_util.check_reconnect()
    sql = '''
            select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
                alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
                alarmAddition, state, alarmTime, update_time 
            from ai_alarminfo where ExamineState=1 and SendState=0 
            '''
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo(camera_id, alarmCode, state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
         alarmAddition, state, alarmTime, update_time
        from ai_alarminfo where camera_id='%s' and alarmCode='%d' and state='%d'
        ''' % (camera_id, alarmCode, state)
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result


def select_alarmid_by_event_id(event_id):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId from ai_alarminfo where event_id='%s'
        ''' % (event_id)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_by_camera(camera_id,alarmCode,state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
         alarmAddition, state, alarmTime, update_time
        from ai_alarminfo where camera_id='%s' and state='%d' ORDER BY update_time desc
        ''' % (camera_id, state)
    # print('-------select_alarminfo_sql_v2-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_by_camera_and_object(camera_id,alarmCode,object_id,state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
         alarmAddition, state, alarmTime, update_time
        from ai_alarminfo where camera_id='%s' and state='%d' and alarmCode='%d' and object_id_total='%s' ORDER BY update_time desc
        ''' % (camera_id, state, alarmCode, object_id)
    # print('-------select_alarminfo_sql_v2-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_by_camera_and_time(camera_id, object_id_total, alarmCode):
    imr_db_util.check_reconnect()
    sql = '''
        SELECT * from ai_alarminfo where camera_id='%s' and alarmCode = '%d' and
        alarmTime>=DATE_SUB(NOW(),INTERVAL 300 SECOND) and object_id_total='%d'
        '''%(camera_id, alarmCode, object_id_total)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_for_light(camera_id):
    imr_db_util.check_reconnect()
    sql = '''
        SELECT * from ai_alarminfo where camera_id='%s' and
        alarmTime>=DATE_SUB(NOW(),INTERVAL 600 SECOND)
        '''%(camera_id)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_by_total_object_id2(camera_id,object_id_total,alarmCode, state=1):
    imr_db_util.check_reconnect()
    try:
        sql ="select  * from ai_alarminfo where camera_id='{}' and object_id_total = '{}' and alarmCode = '{}' and state='{}' ORDER BY update_time DESC".format (camera_id, object_id_total, alarmCode, state)
        # print('-------select_alarminfo_by_total_object_id-------', sql)
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    # print('#######select_alarminfo_by_total_object_id:',result)
    return result

def select_alarminfo_by_total_object_id(camera_id,object_id_total, state=1):
    imr_db_util.check_reconnect()
    try:
        sql ="select  * from ai_alarminfo where camera_id='{}' and object_id_total = {} and state={} ORDER BY update_time DESC".format (camera_id, object_id_total, state)
        # print('-------select_alarminfo_by_total_object_id-------', sql)
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    # print('#######select_alarminfo_by_total_object_id:',result)
    return result

def select_alarminfo_by_time(camera_id):
    imr_db_util.check_reconnect()
    try:
        sql ="select  * from ai_alarminfo where camera_id='{}' and alarmTime>=DATE_SUB(NOW(),INTERVAL 1 MINUTE)".format (camera_id)
        print('-------select_alarminfo_by_time-------', sql)
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    # print('#######select_alarminfo_by_total_object_id:',result)
    return result


def select_alarminfo_avaiable(state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
                alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
                alarmAddition, state, alarmTime, update_time from ai_alarminfo where state=%d
    ''' % state
    # print('-------sqlalarminfo---------',sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_alarminfo_by_alarmid(alarmid):
    imr_db_util.check_reconnect()
    sql = """select original_data_id, alarmEventCategory, alarmTime, alarmType, alarmSeverity, alarmRestored, alarmRestoreTime,
            alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmCode, alarmCause, alarmCauseDesc, alarmAddition,
            camera_id, event_id from ai_alarminfo where alarmId = '%s' """ % alarmid
    # print('-------select_alarminfo_by_alarmid---------', sql)
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


def instert_alarminfo(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
         alarmCauseDesc, alarmAddition, state=1):
    imr_db_util.check_reconnect()
    uuid = new_id()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # print('------alarmType------',type(alarmType))
    # print('------alarmSeverity------',type(alarmSeverity))
    # print('------alarmCode------',type(alarmCode))
    # print('------alarmEventCategory------',type(alarmEventCategory))
    # print('------state------',state)

    sql = ''' 
        insert into ai_alarminfo(alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, 
         alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, 
         alarmCauseDesc, alarmAddition, state, alarmTime, update_time)
        values("%s", "%s", "%s", "%s", "%d", "%d", "%d", "%s", "%s", "%s", "%d", "%s", "%d", "%s", "%s", "%s", "%d", "%s", "%s")
    ''' % (uuid, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, now_str, alarmRestored, alarmCause,
         alarmCauseDesc, alarmAddition, state, now_str, now_str)

    # print('-------instert_alarminfo_sql-------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        traceback.print_exc()
    return uuid,now_str


def instert_alarminfo_object_id(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,alarmConfirmTime,
                      alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
                      alarmCauseDesc, alarmAddition, object_id_total, alarmTime, state=1):
    imr_db_util.check_reconnect()
    uuid = new_id()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = ''' 
            insert into ai_alarminfo(alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, 
             alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, 
             alarmCauseDesc, alarmAddition, object_id_total, state, alarmTime, update_time)
            values("%s", "%s", "%s", "%s", "%d", "%d", "%d", "%s", "%s", "%s", "%d", "%s", "%d", "%s", "%s", "%s", "%d", "%d", "%s", "%s")
        ''' % (uuid, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
               alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, now_str, alarmRestored,
               alarmCause,
               alarmCauseDesc, alarmAddition, object_id_total,state, alarmTime, now_str)

    # print('-------instert_alarminfo_sql-------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        traceback.print_exc()
    return uuid




def update_alarminfo_updatetime(alarmId):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
                update ai_alarminfo set update_time='%s' where alarmId = '%s'
            """ % (now_str, alarmId)
    # print('-------update_alarminfo_updatetime_sql-------', sql)
    prefecture_df = imr_db_util.dml(sql.strip())


def update_alarm_examine(ExamineState,alarmId):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo set ExamineState=%d where alarmId = '%s'
        """ % (ExamineState, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarm_sendstate(SendState,alarmId):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo set SendState=%d where alarmId = '%s'
        """ % (SendState, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarminfo(alarmId, event_id, original_data_id, alarmSeverity, alarmCode,alarmConfirmTime, alarmCause, alarmCauseDesc):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo set event_id='%s',original_data_id='%s',alarmSeverity='%s',alarmCode=%d, alarmConfirmTime='%s',alarmCause='%s',alarmCauseDesc='%s' where alarmId = '%s'
        """ % (event_id,original_data_id,alarmSeverity,alarmCode,alarmConfirmTime,alarmCause,alarmCauseDesc,alarmId)
    print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarminfo_state(alarmId, state=0):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo set state=%d where alarmId = '%s'
        """ % (state, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarminfo_alarmSeverity_and_alarmCode(alarmId,alarmCode=0,alarmSeverity=4, alarmEventCategory=9,state=1):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo set state=%d,alarmCode='%d',alarmSeverity='%d',alarmEventCategory='%d' where alarmId = '%s'
        """ % (state, alarmCode,alarmSeverity,alarmEventCategory,alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())
    update_alarminfo_updatetime(alarmId)

def update_alarminfo_original_data_id_and_event_id(original_data_id,event_id,alarmId):
    imr_db_util.check_reconnect()
    sql = """
                update ai_alarminfo set original_data_id='%s',event_id='%s'where alarmId = '%s'
            """ % (original_data_id, event_id, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarminfo_object_total_id(temp_id,object_id):
    imr_db_util.check_reconnect()
    sql = """
                update ai_alarminfo set object_total_id='%s'where TO_DAYS(NOW())-TO_DAYS(create_time) = 1 and temp_id = '%s'
            """ % (object_id,temp_id)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

if __name__ == '__main__':
    # camera_id = '01679e82265b427c8b2a22ea5dff269w'
    # event_id = '1c1c8698-4836-11eb-a8a7-80fa5b677d77'
    # original_data_id = 'fc0f0cf0-4835-11eb-9f8a-a4bb6dca9770'
    # alarmType = 0
    # alarmSeverity = 2
    # alarmCode = 2
    # alarmConfirmOperator = ''
    # alarmClearOperator = '智能AI'
    # alarmEventCategory = 1
    # alarmRestored = 2
    # alarmCause = ''
    # alarmCauseDesc = ''
    # alarmAddition = ''
    # state = 0
    # s = select_alarminfo(camera_id, alarmCode, state)
    # s = select_alarminfo_by_camera(camera_id, 0)
    # # s = select_alarminfo_avaiable(state)
    # # s = instert_alarminfo(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
    # #      alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
    # #      alarmCauseDesc, alarmAddition)
    # # s = update_alarminfo_updatetime()
    # print(s)
    #alarmid = '3949478a-5615-11eb-b0f7-80fa5b677d77'
    #r = select_alarminfo_by_alarmid(alarmid)
    #print(r)
    camera_id='4af1eb19-66be-11ec-b9dd-00ff862724fc'
    alarmCode=0
    object_id='1'
    select_alarminfo_by_camera_and_object(camera_id,alarmCode,object_id,state=1)

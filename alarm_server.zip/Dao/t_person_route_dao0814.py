# -*- coding: UTF-8 -*-

from Core import db_util
from datetime import datetime


def select_img_id_by_person_id (person_id) :
    db_util.check_reconnect()
    sql = """
                select image_id from t_person_route where person_id = '%s' order by update_time desc limit 1
                """ % person_id
    result = db_util.query(sql)[0][0]
    return result

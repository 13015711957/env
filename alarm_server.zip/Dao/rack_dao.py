# -*- coding: UTF-8 -*-

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime

from Core import imr_db_util

def select_camera_by_rack(rack_name):
    imr_db_util.check_reconnect()
    sql = """
                select roomid, camera_id from rack where name = '%s' LIMIT 1""" % rack_name
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

if __name__ == '__main__':
    rack_name = 'B-16'
    r = select_camera_by_rack(rack_name)
    print(r)
    camera_id = r[0]["camera_id"]
    print(rack_name,camera_id)

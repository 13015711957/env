# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  ai_model_event_dao
@Desc   ：
==================================================
"""
import sys
import os

from datetime import datetime
import traceback
# from Core import db_util
# from util.new_id import new_id
from Core import imr_db_util
from util.new_id import new_id

def instert_model_event(event_id, event_type,event_class,event_name,original_data_id,task_id,camera_id,algorithm_type,start_time=datetime.now(),end_time=datetime.now(),state=1,personnel_id=None):

    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if personnel_id is None:
        personnel_id='-1'
    sql = """
            insert into ai_model_event (event_id,event_type,event_class,event_code,original_data_id,task_id,camera_id,algorithm_type,state,create_time, start_time, end_time,personnel_id) values ('%s','%s','%s','%s','%s','%d','%s','%d','%d','%s','%s','%s','%s') returning event_id
        """ % (event_id,event_type,event_class,event_name,original_data_id,task_id,camera_id,algorithm_type,state,now_str,start_time,end_time,personnel_id)
    # print('--------------instert_model_event_sql--------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        print("{}事件信息插入失败！".format(event_id))
        traceback.print_exc()
    return event_id

def select_model_event(event_id):
    imr_db_util.check_reconnect()
    sql = """
            select event_id,event_type,event_class,event_code,original_data_id,task_id,camera_id,algorithm_type,state,create_time
            from ai_model_event where event_id = '%s' """ % event_id
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


def select_nearest_model_event(camera_id):
    imr_db_util.check_reconnect()
    ####样例sql  select top 1 * from MyTable Order By ModifyTime Desc 查询最近的一条语句
    sql = """
                    select * from ai_model_event where camera_id = '%s' ORDER BY create_time desc LIMIT 2""" % camera_id
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


def update_event_examine(ExamineState, event_id):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_model_event set ExamineState=%d where event_id = '%s'
        """ % (ExamineState, event_id)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_event_code(event_code, event_id):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_model_event set event_code=%d where event_id = '%s'
        """ % (event_code, event_id)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_event_sendstate(SendState, event_id):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_model_event set SendState=%d where event_id = '%s'
        """ % (SendState, event_id)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_eventinfo(event_id,event_name):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_model_event set event_code='%s' where event_id = '%s'
        """ % (event_name, event_id)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def delete_model_event(event_id):
    imr_db_util.check_reconnect()
    try:
        sql = "delete from ai_model_event where event_id = '{}'".format(event_id)
        print("删除预事件信息",sql)
        res = imr_db_util.dml(sql)
    except:
        traceback.pri_exc()
    return res

def update_data_to_ai_model_event(res,event_id):
    imr_db_util.check_reconnect()
    tb = 'ai_model_event'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'update %s' % tb + ' set ' + ','.join([str(i[0])+'='+str(repr(i[1])) for i in lis]) + " where event_id = '%s';" % event_id
    print(sentence)
    insert_id = imr_db_util.dml(sentence)
    return insert_id

if __name__ == '__main__':
    res=update_event_code(-1,'252b76e8-3ac1-11eb-8ae5-80fa5b677d77')
    print(res)
    # camera_id = '01679e82265b427c8b2a22ea5dff215b'
    # now_time = datetime.now()
    # result = select_nearest_model_event(camera_id)
    # diff = now_time - result[0]["create_time"]
    # print(diff)
    # print(result)
    # if diff.seconds>= 60:
    #     print("OK")
    # "b48bf6ca-49d6-11eb-b944-a4bb6dca9770", 0, "0", "3", "b4623362-49d6-11eb-abce-a4bb6dca9770", "5", "01679e82265b427c8b2a22ea5dff269w", "0", 1, "2020-12-29 21:06:46"
    pass


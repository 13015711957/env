from Core import db_util
from datetime import datetime
import traceback

def insert_stream_monitor(camera_id, ds_id, action, state):
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql='''
          insert into t_stream_monitor (camera_id, ds_id, action, state, create_time) values ('%s', '%d', '%s', '%d', '%s') returning camera_id
        '''%(camera_id, ds_id, action, state, now_str)
    print(sql)
    try:
        prefecture_df = db_util.dml(sql.strip())
    except:
        traceback.print_exc()


# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  r_data_center
@Desc   ：
==================================================
"""
import sys
import os

from datetime import datetime
import traceback

from Core import imr_db_util
from util.new_id import new_id




def select_data_center(roomid):
    imr_db_util.check_reconnect()
    sql = '''
                select dc_id
                from serverroom where roomid='%s'
                ''' % (roomid)
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
        # print(sql)
        # print(result)
    except:
        result = False
    dc_id=result[0]['dc_id']
    sql = '''
            select id,dc_name
            from r_data_center where id='%s'
            '''%(dc_id)
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def select_serverroom_id(roomid):
    imr_db_util.check_reconnect()
    sql = '''
            select dc_id
            from serverroom where roomid='%s'
            '''%(roomid)
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result




if __name__ == '__main__':

    alarmid = '3949478a-5615-11eb-b0f7-80fa5b677d77'
    r=select_data_center('4084')
    print(r)


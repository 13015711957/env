from Core import db_util
from datetime import datetime


def insert_image_info(image_type, image_format, image_uri, object_id):
    try:
        db_util.check_connect()
        sql = "insert into t_image_info (image_type, image_format, image_uri, object_id, defun_ind, create_time) " \
              "VALUES ('{}', '{}', '{}', '{}', '{}', '{}')".format(image_type, image_format, image_uri, object_id, 0,
                                                                   datetime.now())
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datetime import datetime

from Core import db_util

def change_alarminfo(alarmSeverity ,alarmCode, alarmTime,happen_time):
    db_util.check_reconnect()
    sql="update ai_alarminfo set alarmSeverity='{}' , alarmCode={} , alarmTime ='{}' where alarmTime ='{}'".format(alarmSeverity ,alarmCode,happen_time, alarmTime)
    print(sql)
    prefecture_df = db_util.dml(sql.strip())

def select_id(alarTime):
    db_util.check_reconnect()
    sql="select event_id,original_data_id from ai_alarminfo where alarmTime = '{}'".format(alarTime)
    print(sql)
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def change_event_face_id(event_id,happen_time,face_id):
    db_util.check_reconnect()
    sql="update ai_model_event_data set face_id='{}',create_time='{}' where event_id = '{}'".format(face_id,happen_time,event_id)
    print(sql)
    prefecture_df = db_util.dml(sql.strip())

def change_original_face_id(original_data_id,face_id):
    db_util.check_reconnect()
    sql="update ai_original_data_detail set face_id ='{}' where original_data_id ='{}'".format(face_id,original_data_id)
    print(sql)
    prefecture_df = db_util.dml(sql.strip())

def run(alarmTime,happen_time,face_id='unknown'):
    res = select_id(alarmTime)
    print(res)
    event_id = res[0]['event_id']
    original_data_id = res[0]['original_data_id']
    print(event_id,original_data_id)
  
    if face_id == 'unknown':
        change_alarminfo('3',13,alarmTime,happen_time)
    else:
        change_alarminfo('0',-1,alarmTime,happen_time)
    change_event_face_id(event_id,happen_time,face_id)
    change_original_face_id(original_data_id,face_id)

if __name__=='__main__':
    alarmTime ='2022-03-08 16:33:50'
    face_id = 'unknown'
    #happen_time ='2022-02-07 10:43:56'

    happen_time = alarmTime
    run(alarmTime,happen_time,face_id)
    
    os._exit(0)


# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: t_log_dao
@Author  :linych 
@Time    :2020/12/9 15:08
@Desc  : 
'''

import ailog

from Core import mysql_log_loop
async def insert_log(url='', seqid='', method='', args='', output='', code='', use_time=0, create_time=''):

    try:

        ailog.info('insert_log')

        args = args.replace("'",'')
       


        sql = "insert into shv_request_record_log (url,seqid,method,args,output,code,use_time,create_time) \
           VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(url, seqid, method, args, output,code, use_time, create_time)

        await mysql_log_loop.db_util.execute(sql)
        ailog.debug(sql)
    except Exception as e:
        ailog.error('Mysql error : {}'.format(e))






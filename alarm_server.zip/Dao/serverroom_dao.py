import sys
import os

from datetime import datetime

from Core import db_util
from util.new_id import new_id

def select_serverroom(roomid):
    db_util.check_reconnect()
    sql = """
            select name from serverroom where roomid = '% s' """ %roomid
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"name":"未知"}]
    return result

def select_areacode(roomid):
    db_util.check_reconnect()
    sql = """
            select areacode from serverroom where roomid = '% s' """ %roomid
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"areacode":"未知"}]
    return result

def select_dcid_by_roomid(roomid):
    db_util.check_reconnect()
    sql = """
            select dc_id from serverroom where roomid = '% s' """ %roomid
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"dc_id":"未知"}]
    return result



if __name__ == '__main__':
    pass

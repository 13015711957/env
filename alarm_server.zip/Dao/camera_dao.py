import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datetime import datetime

from Core import db_util
from util.new_id import new_id

def select_camera(camera_id):
    db_util.check_reconnect()
    sql = """
            select roomid from camera where id = '%s' """ %camera_id
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"roomid":4086}]
        print("根据照相机id:{}查询机房信息失败！".format(camera_id))
    return result
def select_device(camera_id):
    db_util.check_reconnect()
    sql = """
            select deviceId,name from camera where id = '%s' """ %camera_id
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result

def get_camera_map():
    sql = "select id,algorithm from camera "
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    camera_map=dict()
    if len(result)>0:
        for item in result:
            camera_map[item["id"]]=item["algorithm"]
    return camera_map

def get_roomid_map():
    sql = "select id,roomid from camera "
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    camera_map=dict()
    if len(result)>0:
        for item in result:
            camera_map[item["id"]]=item["roomid"]
    return camera_map
#
# def get_camera_map():
#     sql = "select * from ai_camera_map "
#     result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
#     camera_map=dict()
#     if len(result)>0:
#         for item in result:
#             camera_map[item["camera_id"]]=item["camera_chanel_name"]
#     return camera_map

def select_camera_zhiwu_pic(camera_id):
    db_util.check_reconnect()
    sql = """
                select model_picture_url from camera where id = '%s' """ % camera_id
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')

    return result

def select_camera_door_area(camera_id):
    db_util.check_reconnect()
    sql = """
                select door_area from camera where id = '%s' """ % camera_id
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')

    return result

def select_camera_working_area(camera_id):
    db_util.check_reconnect()
    sql = """
                select working_area from camera where id = '%s' """ % camera_id
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')

    return result

def select_camera_warning_area(camera_id):
    db_util.check_reconnect()
    sql = """
                select warning_area from camera where id = '%s' """ % camera_id
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')

    return result

def select_cameraarea(camera_id):
    db_util.check_reconnect()
    sql = """ select cameraarea from camera where id = '%s' """ % camera_id
    print('-------select_alarminfo_by_alarmid---------', sql)
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_camera_by_deepstream(deepstream_camera_id):
    db_util.check_reconnect()
    sql = "select camera_uid from ai_camera_map where camera_id ={} ".format(deepstream_camera_id)
    # print('sql: ',sql)
    try:
        result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"roomid":4086}]
        print("根据照相机id:{}查询机房信息失败！".format(deepstream_camera_id))
    return result


if __name__ == '__main__':
    camera_id = '01679e82265b427c8b2a22ea5dff221b'
    result = select_cameraarea(camera_id)
    camera_id = '01679e82265b427c8b2a22ea5dff221b'
    result = select_camera(camera_id)
    print(result)
    working_area=result[0]["door_area"]
    import json
    working_area = json.loads(working_area)
    print(result)


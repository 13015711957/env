from Core import db_util
from datetime import datetime


def insert_rslt_flow(flow_id, track_id):
    try:
        db_util.check_connect()
        sql = "insert into t_rslt_flow (flow_id, track_id, start_time, end_time, create_time, defun_ind) " \
              "VALUES ('{}', '{}', '{}', '{}', '{}', '{}')".format(flow_id, track_id, datetime.now(),
                                                                   datetime.now(), datetime.now(), 0)
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()
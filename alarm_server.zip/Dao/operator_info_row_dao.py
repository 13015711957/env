# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：warning_module
@File   :  ai_original_data_detail
@Desc   ：
==================================================
"""
import sys
import os

from datetime import datetime

from Core import imr_db_util
from util.new_id import new_id

def select_operator_info_row(operatorid):
    imr_db_util.check_reconnect()
    ####样例sql  select top 1 * from MyTable Order By ModifyTime Desc 查询最近的一条语句
    sql = """
                select equipment_site_room, equipment_site_rack, work_end_date from operator_info_row where operatorid = '%s'ORDER BY work_end_date desc LIMIT 1""" % operatorid
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_operator_allow_info(operatorid):
    now_time = datetime.now()
    imr_db_util.check_reconnect()
    sql = """
                select * from operator_info_row where operatorid = '%s' and work_start_date < now() and now() < work_end_date """ % operatorid
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


if __name__ == '__main__':
    id = 'testJL'
    r = select_operator_info_row(id)
    print(r)
    d = r[0]["work_end_date"]
    if d > datetime.now():
        print('ok')

# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_event_person_dao
@Time    : 2021/5/20 15:57
@Author  : chenych
@Desc    :
"""

import time
from Core import db_util


def insert_event_person(event_id, sex, age, person_id):
    if person_id is None:
        person_id = 0
    sql = 'INSERT INTO t_event_person(event_id,sex, age, person_id,create_time,defun_ind)'
    sql += ' VALUES("%s","%s","%s","%s","%s",0)'%(event_id,sex, age, person_id, time.strftime('%Y-%m-%d %H:%M:%S'))
    
    db_util.dml(sql)

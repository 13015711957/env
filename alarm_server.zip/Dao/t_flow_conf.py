from Core import db_util


def select_flow_conf():
    try:
        db_util.check_connect()
        sql = "select flow_id, camera_id, area_from, area_to from t_flow_conf where defun_ind='{}'".format(0,)
        res = db_util.query(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()
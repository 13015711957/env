import base64
import numpy as np
import cv2
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from Core import db_util
from datetime import datetime

def update_id(original_data_id,id):
    db_util.check_reconnect()
    sql="""UPDATE "room50"."ai_original_data_detail" SET "id" = {} WHERE "id" IS NULL AND "original_data_id" = '{}' """.format(id,original_data_id)
    print(sql)
    res = db_util.dml(sql)
    return res

def select_id_null():
    db_util.check_reconnect()
    sql="select original_data_id from ai_original_data_detail where id is null "
    print(sql)
    res = db_util.query(sql=sql.strip(), ret_type='all_dict')
    return res

if __name__=='__main__':
    res = select_id_null()
    print(res)
    i=3115461
    for item in res:
        i+=1
        original_data_id=item['original_data_id']
        update_id(original_data_id,i)

# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: t_goods_area_dao
@Time    : 2021/5/21 17:52
@Author  : chenych
@Desc    :
"""

from Core import db_util


def get_goods_area_data():
    sql = 'SELECT * FROM t_goods_area WHERE defun_ind=0'

    res = db_util.query(sql, 'all_dict')
    return res

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Core import mon_db_util
from datetime import datetime
import traceback

def insert_monitor_data(server_name, status, use_time):
    mon_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    table_name ='imr_'+server_name
    sql='''
          insert into "%s" (status, use_time, create_time) values ("%d","%s","%s")
        '''%(table_name, status, use_time, now_str)
    print(sql)
    try:
        prefecture_df = mon_db_util.dml(sql.strip())
    except:
        traceback.print_exc()

def insert_monitor_alarm_data(alarmCode, alarmDesc):
    mon_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql='''
          insert into imr_alarm (alarmCode, alarmDesc, create_time) values ("%d","%s","%s")
        '''%(alarmCode, alarmDesc, now_str)
    print(sql)
    try:
        prefecture_df = mon_db_util.dml(sql.strip())
    except:
        traceback.print_exc()

def alarm_map(alarmCode):
    AlarmMap = {
        11: '门禁越权',
        12: '跟人带人',
        13: '非法闯入',
        21: '接触高危设备',
        22: '超出工作区域',
        23: '未戴安全帽',
        24: '未穿工作服',
        31: '异物发现',
        32: '通道阻塞',
        33: '人员跌倒',
        34: '火情告警',
    }
    return AlarmMap.get(alarmCode, None)

if __name__=='__main__':
    import time
    server_name= 'person_manage'
    status = 1
    now_time = time.time()
    time.sleep(1)
    use_time = time.time()-now_time
    insert_monitor_data(server_name,status,use_time)

    alarmCode = 11
    alarmDesc = alarm_map(11)
    insert_monitor_alarm_data(alarmCode,alarmDesc)
# -*- coding: utf-8 -*-

'''
@project : AIGateWay_fastapi
@FileName: t_error_log
@Author  :linych 
@Time    :2020/12/19 11:26
@Desc  : 
'''

from Core import mysql_ailog_loop


async def insert_error_log(message,asctime,name,pathname,process,processName,filename,threadName,levelname,funcName,thread,lineno,stack_info,exc_text,exc_info,**kwargs):
    try:

        message = message.replace("'",'')
        exc_text = exc_text.replace("'",'')
        exc_info = exc_info.replace("'",'')

        pathname = pathname.replace("\\",'\\\\')



        sql = "insert into ai_error_log (message,asctime,name,pathname,process,processName,filename,threadName,levelname,funcName,thread,lineno,stack_info,exc_text,exc_info) \
           VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(message,asctime,name,pathname,process,processName,filename,threadName,levelname,funcName,thread,lineno,stack_info,exc_text,exc_info)


        await mysql_ailog_loop.db_util.execute(sql)

    except Exception as e:
        print('Mysql insert_error_log error : {}'.format(e))

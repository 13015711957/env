# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：video_analysis
@File   :  ai_original_data_detail_dao
@Desc   ：
==================================================
"""

from Core import imr_db_util
from datetime import datetime


class AiOriginalDataDetailConstant:
    SJLX_OBJ = 1
    SJLX_FACE = 0


def insert_data_to_ai_original_data_detail(res):
    imr_db_util.check_reconnect()
    tb = 'ai_original_data_detail'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'insert into %s (' % tb + ','.join([i[0] for i in lis]) + \
                   ') VALUES (' + ','.join(repr(i[1]) for i in lis) + ') returning original_data_id;'
    #print(sentence)
    insert_id = imr_db_util.dml(sentence)
    return insert_id


def select_ai_original_data_detail(original_data_id):
    imr_db_util.check_reconnect()
    sql = """
                select box, label, scores from ai_original_data_detail where original_data_id = '%s' 
                """ % original_data_id
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_ai_original_data_detail_face_id(face_id):
    imr_db_util.check_reconnect()
    sql = """
                select * from ai_original_data_detail where TO_DAYS(NOW())-TO_DAYS(create_time) = 0 and face_id='%s' order by create_time desc limit 1
                """ % face_id
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def update_original_data_detail_face_id(temp_id,person_name):
    imr_db_util.check_reconnect()
    sql = """update ai_original_data_detail set face_id='%s' where TO_DAYS(NOW())-TO_DAYS(create_time) = 0 and face_id='%s'"""%(person_name,temp_id)
    result=imr_db_util.dml(sql.strip())
    return result

def update_original_info(original_date_id,face_id,face_score):
    imr_db_util.check_reconnect()
    sql = """update ai_original_data_detail set face_id='%s',face_score='%d' where original_data_id='%s'"""%(face_id,face_score,original_date_id)
    result=imr_db_util.dml(sql.strip())
    return result

def update_base64(original_data_id,imgb64):
    imr_db_util.check_reconnect()
    sql="update ai_original_data_detail set base64='{}' where original_data_id='{}'".format(imgb64,original_data_id)
    print(sql)
    res = imr_db_util.dml(sql)
    return res

def update_data_to_ai_original_data_detail(res,original_data_id):
    imr_db_util.check_reconnect()
    tb = 'ai_original_data_detail'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'update %s' % tb + ' set ' + ','.join([str(i[0])+'='+str(repr(i[1])) for i in lis]) + " where original_data_id = '%s'" % original_data_id
    print(sentence)
    insert_id = imr_db_util.dml(sentence)
    return insert_id

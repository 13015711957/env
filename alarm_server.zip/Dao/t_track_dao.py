# -*- encoding: utf-8 -*-
"""
@Project : VideoShowHall
@FileName: t_camera_conf_dao
@Time    : 2021/5/12 15:05
@Author  : chenych
@Desc    :
"""
from Core import db_util





from Core import db_util
from datetime import datetime


def insert_track_info(camera_id,person_id,image_id,start_time,address,box,face_score):
    try:
        db_util.check_connect()
        sql = "insert into t_person_route (camera_id, person_id, image_id, start_time, create_time, address,box,face_score) "\
              "VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(camera_id, person_id, image_id, start_time,
                                                                   datetime.now(), address, box,face_score)
        print(sql)
        res = db_util.dml(sql)
        print('sql result : {}'.format(res))
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def update_track_info(rid,end_time):

    try:
        db_util.check_connect()

        sql = "update t_person_route set end_time='{}',update_time='{}' where route_id={}".format(end_time,datetime.now(),rid)

        print(sql)

        db_util.dml(sql)

    except Exception as e:
        import traceback
        traceback.print_exc()

def insert_t_track(camera_id, track_type):
    try:
        db_util.check_connect()
        sql = "insert into t_track (camera_id, track_type, start_time, end_time, create_time) " \
              "VALUES ('{}','{}','{}','{}','{}')".format(camera_id, track_type, datetime.now(), datetime.now(),
                                                         datetime.now())
        res = db_util.dml(sql)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()

def select_person_route_nearly(camera_id):
    db_util.check_reconnect()
    sql = """SELECT * from t_person_route where create_time>=DATE_SUB(NOW(),INTERVAL 3 MINUTE) and camera_id = '{}'
    order by face_score desc limit 1""".format(camera_id)
    # print('-------select_alarminfo_by_alarmid---------', sql)
    result = db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result



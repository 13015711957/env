# -*- encoding: utf-8 -*-
"""
@Project : VideoShowHall 
@FileName: t_camera_conf_dao
@Time    : 2021/5/12 15:05
@Author  : chenych
@Desc    :
"""
import pandas as pd
from Core import mysql_log_loop
from Core import db_util


async def aysnc_get_all_camera_conf():
    sql = 'SELECT * FROM t_camera_conf'
    res = await mysql_log_loop.db_util.query(sql)

    if len(res)==0:
        print('#无数据')
        return None
    df = pd.DataFrame(res)

    df.drop_duplicates(['camera_id'], inplace=True)
    df.set_index(['camera_id'], inplace=True)

    return df

def get_all_camera_conf():
    sql = 'SELECT * FROM t_camera_conf'
    res = db_util.query(sql,'all_dict')

    if len(res)==0:
        print('#无数据')
        return None
    df = pd.DataFrame(res)

    df.drop_duplicates(['camera_id'], inplace=True)
    #df.set_index(['camera_id'], inplace=True)

    return df


def get_all_camera_event():
    sql = 'SELECT id,camera_id,event_type FROM t_camera_conf WHERE defun_ind=0'
    res = db_util.query(sql, 'all_dict')
    return res
    

def get_camera_conf(camera_id, event_type):
    sql = "SELECT id,camera_id,event_type FROM t_camera_conf " \
          "WHERE camera_id='{}' and event_type='{}' and defun_ind='{}'".format(camera_id, event_type, 0)
    res = db_util.query(sql, 'one')
    return res


if __name__ == '__main__':
    # import asyncio
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(get_all_camera_conf())
    # loop.close()
    df = get_all_camera_conf()
    print(df)


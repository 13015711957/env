import sys
import os

from datetime import datetime

from Core import imr_db_util
from util.new_id import new_id


def select_operator_info(operatorid):
    imr_db_util.check_reconnect()
    sql = """
            select credentials_type, staff_name, tel, email from operator_info where operatorid = '%s' """ %operatorid
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_face_id_by_name(staff_name):
    imr_db_util.check_reconnect()
    sql = """
            select operatorid from operator_info where staff_name = '%s' """ %staff_name
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

def select_operator_type_by_id(operatorid):
    imr_db_util.check_reconnect()
    sql = """
            select type from operator_info where operatorid = '%s' """ %operatorid
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result

if __name__ == '__main__':
    oid = 'unknown_20210106_0'
    r = select_operator_info(oid)
    person_name='鲍云飞'
    r = select_face_id_by_name(person_name)
    print(r)

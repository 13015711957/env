# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：video_analysis
@File   :  ai_original_data_dao
@Desc   ：
==================================================
"""

from Core import imr_db_util
from datetime import datetime


def insert_data_to_ai_original_data(res):
    imr_db_util.check_reconnect()
    tb = 'ai_original_data'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'INSERT into %s (' % tb + ','.join([i[0] for i in lis]) + \
                   ') VALUES (' + ','.join(repr(i[1]) for i in lis) + ') returning original_data_id'
    insert_id = imr_db_util.dml(sentence)

    return insert_id

def select_original_data(origital_data_id):
    imr_db_util.check_reconnect()
    sql="""select address,box from ai_original_data where original_data_id='%s'
    """%(origital_data_id)
    result=imr_db_util.query(sql=sql.strip(),ret_type='all_dict')
    return result

def update_data_to_ai_original_data(res,original_data_id):
    imr_db_util.check_reconnect()
    tb = 'ai_original_data'
    lis = [(k, v) for k, v in res.items() if v != '']
    sentence = 'update %s' % tb + ' set ' + ','.join([str(i[0])+'='+str(repr(i[1])) for i in lis]) + " where original_data_id = '%s';" % original_data_id
    #print(sentence)
    insert_id = imr_db_util.dml(sentence)
    return insert_id

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datetime import datetime

from Core import imr_db_util
from util.new_id import new_id

def select_provinfo(areacode):
    imr_db_util.check_reconnect()
    sql = """
            select province,city,provinceid from dim_admincode where code = '% s' """ %areacode
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = [{"province":"未知","city":"未知","provinceid":"未知"}]
    return result
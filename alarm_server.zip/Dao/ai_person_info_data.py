# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject
@FileName: t_event_dao
@Time    : 2021/5/20 15:34
@Author  : chenych
@Desc    :
"""
from Core import db_util
import time


def select_person_info_by_personid(person_id):
    sql = 'SELECT  * FROM t_person_info WHERE t_person_info.name  IS NOT NULL AND  t_person_info.person_id={}'.format(person_id)
    res = db_util.query(sql,  ret_type='all_dict')
    return res


if __name__ == '__main__':
    person_id = '204'
    person_info = select_person_info_by_personid(person_id)
    print(person_info[0]['name'])
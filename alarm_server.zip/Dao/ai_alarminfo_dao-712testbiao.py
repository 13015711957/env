# -*- coding: UTF-8 -*-
"""
=================================================
@Project ：IntelligentMachineRoom
@File   :  ai_alarminfo_dao
@Desc   ：
==================================================
"""
import sys
import os

from datetime import datetime
import traceback

from Core import imr_db_util
from util.new_id import new_id


def select_alarminfo(camera_id, alarmCode, state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
         alarmAddition, state, alarmTime, update_time
        from ai_alarminfo_0712 where camera_id='%s' and alarmCode='%d' and state='%d'
        ''' % (camera_id, alarmCode, state)
    # print('-------select_alarminfo_sql-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result



def select_alarminfo_by_camera(camera_id,state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, alarmConfirmTime,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, alarmCauseDesc,
         alarmAddition, state, alarmTime, update_time
        from ai_alarminfo_0712 where camera_id='%s' and state='%d' ORDER BY update_time
        ''' % (camera_id, state)
    # print('-------select_alarminfo_sql_v2-------', sql)
    try:
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result


def select_alarminfo_by_total_object_id(camera_id,object_id_total,state=1):
    # imr_db_util.check_reconnect()

    # print('-------select_alarminfo_by_total_object_id-------', sql)
    try:
        sql ="select  * from ai_alarminfo_0712 where camera_id='{}' and object_id_total = {} and state={} ORDER BY update_time DESC".format (camera_id, object_id_total, state)
        result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    except:
        result = False
    return result



def select_alarminfo_avaiable(state=1):
    imr_db_util.check_reconnect()
    sql = '''
        select alarmId, alarmTime, update_time from ai_alarminfo_0712 where state=%d
    ''' % state
    # print('-------sqlalarminfo---------',sql)
    try:
        result = imr_db_util.query(sql=sql.strip())
    except:
        result = False
    return result

def select_alarminfo_by_alarmid(alarmid):
    imr_db_util.check_reconnect()
    sql = """select original_data_id, alarmEventCategory, alarmTime, alarmType, alarmSeverity, alarmRestored, alarmRestoreTime,
            alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmCode, alarmCause, alarmCauseDesc, alarmAddition,
            camera_id, event_id from ai_alarminfo_0712 where alarmId = '%s' """ % alarmid
    # print('-------select_alarminfo_by_alarmid---------', sql)
    result = imr_db_util.query(sql=sql.strip(), ret_type='all_dict')
    return result


def instert_alarminfo(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
         alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
         alarmCauseDesc, alarmAddition, state=1):
    imr_db_util.check_reconnect()
    uuid = new_id()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # print('------alarmType------',type(alarmType))
    # print('------alarmSeverity------',type(alarmSeverity))
    # print('------alarmCode------',type(alarmCode))
    # print('------alarmEventCategory------',type(alarmEventCategory))
    # print('------state------',state)

    sql = ''' 
        insert into ai_alarminfo_0712(alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, 
         alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, 
         alarmCauseDesc, alarmAddition, state, alarmTime, update_time)
        values("%s", "%s", "%s", "%s", "%d", "%d", "%d", "%s", "%s", "%s", "%d", "%s", "%d", "%s", "%s", "%s", "%d", "%s", "%s")
    ''' % (uuid, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
         now_str, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, now_str, alarmRestored, alarmCause,
         alarmCauseDesc, alarmAddition, state, now_str, now_str)

    # print('-------instert_alarminfo_sql-------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        traceback.print_exc()
    return uuid,now_str


def instert_alarminfo_object_id(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
                      alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
                      alarmCauseDesc, alarmAddition, object_id_total, state=1):
    imr_db_util.check_reconnect()
    uuid = new_id()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = ''' 
            insert into ai_alarminfo_0712(alarmId, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode, 
             alarmConfirmTime, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestoreTime, alarmRestored, alarmCause, 
             alarmCauseDesc, alarmAddition, object_id_total, state, alarmTime, update_time)
            values("%s", "%s", "%s", "%s", "%d", "%d", "%d", "%s", "%s", "%s", "%d", "%s", "%d", "%s", "%s", "%s", "%d", "%d", "%s", "%s")
        ''' % (uuid, camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
               now_str, alarmConfirmOperator, alarmClearOperator, alarmEventCategory, now_str, alarmRestored,
               alarmCause,
               alarmCauseDesc, alarmAddition, object_id_total,state, now_str, now_str)

    # print('-------instert_alarminfo_sql-------', sql)
    try:
        prefecture_df = imr_db_util.dml(sql.strip())
    except:
        traceback.print_exc()
    return uuid, now_str




def update_alarminfo_updatetime(alarmId):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
                update ai_alarminfo_0712 set update_time='%s' where alarmId = '%s'
            """ % (now_str, alarmId)
    # print('-------update_alarminfo_updatetime_sql-------', sql)
    prefecture_df = imr_db_util.dml(sql.strip())


def update_alarminfo_state(alarmId, state=0):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo_0712 set state=%d where alarmId = '%s'
        """ % (state, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())

def update_alarminfo_alarmSeverity_and_alarmCode(alarmId,alarmCode=0,alarmSeverity=4, alarmEventCategory=9,state=1):
    imr_db_util.check_reconnect()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sql = """
            update ai_alarminfo_0712 set state=%d,alarmCode='%d',alarmSeverity='%d',alarmEventCategory='%d' where alarmId = '%s'
        """ % (state, alarmCode,alarmSeverity,alarmEventCategory,alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())
    update_alarminfo_updatetime(alarmId)

def update_alarminfo_original_data_id_and_event_id(original_data_id,event_id,alarmId):
    imr_db_util.check_reconnect()
    sql = """
                update ai_alarminfo_0712 set original_data_id='%s',event_id='%s'where alarmId = '%s'
            """ % (original_data_id, event_id, alarmId)
    # print(sql)
    prefecture_df = imr_db_util.dml(sql.strip())


if __name__ == '__main__':
    # camera_id = '01679e82265b427c8b2a22ea5dff269w'
    # event_id = '1c1c8698-4836-11eb-a8a7-80fa5b677d77'
    # original_data_id = 'fc0f0cf0-4835-11eb-9f8a-a4bb6dca9770'
    # alarmType = 0
    # alarmSeverity = 2
    # alarmCode = 2
    # alarmConfirmOperator = ''
    # alarmClearOperator = '智能AI'
    # alarmEventCategory = 1
    # alarmRestored = 2
    # alarmCause = ''
    # alarmCauseDesc = ''
    # alarmAddition = ''
    # state = 0
    # s = select_alarminfo(camera_id, alarmCode, state)
    # s = select_alarminfo_by_camera(camera_id, 0)
    # # s = select_alarminfo_avaiable(state)
    # # s = instert_alarminfo(camera_id, event_id, original_data_id, alarmType, alarmSeverity, alarmCode,
    # #      alarmConfirmOperator, alarmClearOperator, alarmEventCategory, alarmRestored, alarmCause,
    # #      alarmCauseDesc, alarmAddition)
    # # s = update_alarminfo_updatetime()
    # print(s)
    alarmid = '3949478a-5615-11eb-b0f7-80fa5b677d77'
    r = select_alarminfo_by_alarmid(alarmid)
    print(r)

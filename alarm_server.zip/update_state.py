import time

from Dao.ai_alarminfo_dao import update_state

if __name__ == '__main__':
    while True:
        update_state()
        time.sleep(300)

# -*- encoding: utf-8 -*-
"""
@Project : VideoAnalysisProject 
@FileName: rabbitmq_connecter
@Time    : 2021/5/20 17:04
@Author  : chenych
@Desc    :
"""
import time
import pika
import traceback


class MQConneter(object):
    def __init__(self, user, passwd, host, port='5672', vhost='/'):
        self.user = user
        self.passwd = passwd
        self.host = host
        self.port = port
        self.vhost = vhost
        self.con = None
        self.channel = None

        self.mq_connect()

    def __del__(self):
        self.mq_close()

    def mq_connect(self):
        res = False
        max_retry = 3
        for i in range(1, max_retry + 1):
            try:
                credentials = pika.PlainCredentials(self.user, self.passwd)
                parameters = pika.ConnectionParameters(self.host,
                                                       self.port,
                                                       self.vhost,
                                                       credentials,
                                                       heartbeat=0)
                self.con = pika.BlockingConnection(parameters)
                self.channel = self.con.channel()
                res = True
                break
            except:
                print('#Error: 第[%s]次创建连接失败!'%(i))
                traceback.print_exc()
                if i == max_retry:
                    print('#Error: 重试%s次,放弃!' % (max_retry))
                else:
                    time.sleep(10)

        return res

    def mq_close(self):
        try:
            if self.con is not None:
                self.channel.close()
                self.con.close()
        except Exception as e:
            print('#WARN: close error:{}'.format(e))

    def get_channel(self):
        if not self.check_connect():
            return None
        return self.channel

    def check_connect(self):
        res = False
        try:
            if self.con is None or not self.con.is_open or not self.channel.is_open:
                self.mq_close()
                res = self.mq_connect()
            try:
                self.con.process_data_events()
                res = True
            except Exception as e:
                print('#WARN:连接异常,重建连接:{}'.format(e))
                self.mq_close()
                res = self.mq_connect()
            return res
        except:
            print('#ERROR:检测连接异常!')
            traceback.print_exc()
            return False

    def publish_msg(self, queue_name, message):
        chan = self.get_channel()
        if chan is None:
            print(" [WARN] Sent Queue[%s] message failed!" % (queue_name))
            return

        chan.queue_declare(queue=queue_name, durable=True)
        chan.basic_publish(
            exchange='',
            routing_key=queue_name,
            body=message,
            properties=pika.BasicProperties(
                delivery_mode=2,  # make message persistent
            ))
        print(" [x] Sent Queue[%s] message ok" % (queue_name))

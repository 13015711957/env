# -*- coding: utf-8 -*-

'''
@project : AIGateWay_fastapi
@FileName: redis_connecter
@Author  :linych 
@Time    :2020/12/16 21:57
@Desc  : 
'''

import redis
from Core import conf
import random


TASK = 4
PARAM = 3

TASK_NAME = conf.get('REDIS', 'task_deepstream')
Task_host = conf.get('REDIS', 'Task_host')
Task_port = conf.get("REDIS", 'Task_port')
Task_password = conf.get("REDIS", 'Task_password')

Param_host = conf.get('REDIS', 'Param_host')
Param_port = conf.get("REDIS", 'Param_port')
Param_password = conf.get("REDIS", 'Param_password')

TASK_pool = redis.ConnectionPool(host=Task_host, port=Task_port, decode_responses=True, db=TASK, password=Task_password)
redis_Task = redis.StrictRedis(connection_pool=TASK_pool)

PARAM_pool = redis.ConnectionPool(host=Param_host, port=Param_port, decode_responses=True, db=PARAM, password=Param_password)
redis_Param = redis.StrictRedis(connection_pool=PARAM_pool)



# from rediscluster import RedisCluster


# startup_nodes = [{"host": "10.142.157.3", "port": "7001"},
#                  {"host": "10.142.157.3", "port": "7002"},
#                  {"host": "10.142.157.3", "port": "7003"},
#                  {"host": "10.142.157.4", "port": "7004"},
#                  {"host": "10.142.157.4", "port": "7005"},
#                  {"host": "10.142.157.4", "port": "7006"} ]
#
# redis_Task = RedisCluster(startup_nodes=startup_nodes, decode_responses=True)


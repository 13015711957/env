import psycopg2
import sys
import time
import os
import re


# sys.path.append("..")
# from core.util.ReadConfigUtil import ReadConfig

# BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# print(BASE_DIR)
# config_path = BASE_DIR + '/conf/compact.conf'
# alm_cfg = ReadConfig(config_path)


class pgsql_connecter:

    def __init__(self, db_cfg, db_mode='public'):
        self.dbconfig = db_cfg
        self.db_mode = db_mode
        self.db_init()

    def db_init(self):
        self.conn = psycopg2.connect(
            host=self.dbconfig['host'],
            port=int(self.dbconfig['port']),
            database=self.dbconfig['db'],
            user=self.dbconfig['user'],
            password=self.dbconfig['password'],
            options="-c search_path={}".format(self.db_mode),
            keepalives=1,
            keepalives_idle=30,
            keepalives_interval=10,
            keepalives_count=5
        )
        self.cursor = self.conn.cursor()

    # 检查连接
    def check_connect(self):
        flag = True
        try:
            # 判断是否为长连接2006异常
            # self._connect.ping()
            test_connect = self.query('SELECT count(1) FROM ai_attr')
            print(test_connect)
        except:
            print('#PgSQL 链接异常。')
            # self._cursor_dic.close()
            # self._cursor.close()
            # self._connect.close()
            flag = False

        return flag

    # 检查连接,若连接失败重连
    def check_reconnect(self):
        if not self.check_connect():
            for _ in range(6):
                print('PgSQL reconnect ...')
                if self.db_init():
                    return True
                # time.sleep(2)
        else:
            return True

        return False

    def close_db(self):
        self.cursor.close()
        self.conn.close()

    def __del__(self):
        self.close_db()

    def query_all(self, sql):
        self.cursor.execute(sql)
        return self.cursor.fetchall()
        data = [[item for item in row] for row in self.cursor.fetchall()]
        coloumns = [row[0] for row in self.cursor.description]
        self.conn.commit()
        return [dict(zip(coloumns, row)) for row in data]

    def query_one(self, sql):
        self.cursor.execute(sql)
        # data = [[item for item in row] for row in self.cursor.fetchone()]
        data = self.cursor.fetchone()
        return data
        columns = [row[0] for row in self.cursor.description]
        self.conn.commit()
        return [dict(zip(columns, data))]

    def query(self, sql, ret_type='all_dict'):
        try:
            if ret_type == 'all_dict' or ret_type == 'all':
                data = self.query_all(sql)
            else:
                data = self.query_one(sql)
            self.conn.commit()
            return data
        except Exception as e:
            print('======query_error:%s======' % e)
            self.close_db()
            self.db_init()
            data = self.query_all(sql)
            self.conn.commit()
            return data

    def dml_by_val(self, sql, values):
        try:
            id = True
            self.cursor.execute(sql, values)
            type = self.dml_type(str(sql))
            if 't_contract_detail' in sql and 'INSERT' in sql:
                id = self.cursor.fetchone()
                id = id[0]
            self.conn.commit()
            return id
        except Exception as e:
            # self._error_code = e.args[0]
            print("Mysql execute error:", e)
            return False

    def dml_type(self, sql):
        re_dml = re.compile('^(?P<dml>\w+)\s+', re.I)
        m = re_dml.match(sql.strip())
        if m:
            if m.group("dml").lower() == 'delete':
                return 'delete'
            elif m.group("dml").lower() == 'update':
                return 'update'
            elif m.group("dml").lower() == 'insert':
                return 'insert'
        print(
            "%s --- Warning: '%s' is not dml." % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())), sql))
        return False

    def dml(self, sql):
        print(sql)
        self.cursor.execute(sql)
        type = self.dml_type(str(sql))
        # self.conn.commit()
        # if primary key is auto increase, return inserted ID.
        # id = True
        # if type == 'insert':
        #     self.cursor.execute("select nextval('ct_contract_id_seq')")
        #     id = int(self.cursor.fetchone()[0]) - 1
        #     # print(id)
        if type == 'insert':
            # self.cursor.execute("select nextval('ct_contract_id_seq')")
            res = self.cursor.fetchone()[0]
        else:
            res = True
        self.conn.commit()
        return res

    def dml_get_id(self, sql):
        self.cursor.execute(sql)
        type = self.dml_type(str(sql))
        # if primary key is auto increase, return inserted ID.
        # id = True
        id = self.cursor.fetchone()
        id = id[0]
        self.conn.commit()
        return id


if __name__ == '__main__':
    # pgs_oper.reconnect()
    # pg = pgsql_connecter()
    # print(pg.cursor)
    pass

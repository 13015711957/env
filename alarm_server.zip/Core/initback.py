# -*- coding: utf-8 -*-

'''
@project : AI_ControlServer
@FileName: __init__.py
@Desc  : 
'''

import os
import sys

import Core.sys_code_config as SYS_CODE
from Core.config_util import ConfigUtil
from Core.mysql_connecter import mysql_connecter
from Core.AsyncThreadLoop import AsyncThreadLoop
from Core.AsyncMysqlLoop import AsyncMysqlThreadLoop
__all__ = ['conf', 'db_util', 'SYS_CODE', 'root_path', 'log_path']




config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if os.path.exists(r'/opt/config/config.ini'):
    config_path = r'/opt/config/'

print("config_path: ", config_path)
try:
    conf = ConfigUtil(config_path=os.path.join(config_path, 'config.ini'))
except Exception as e:
    print('config read error : {}'.format(e))

time_config={
    'stand_time':conf.get(section='time_second',option='stand_time'),
    'elapsed_time':conf.get(section='time_second',option='elapsed_time')
}

mysql_config = {
    'user': conf.get(section='Mysql', option='user'),
    'password': conf.get(section='Mysql', option='password'),
    'db': conf.get(section='Mysql', option='db'),
    'host': conf.get(section='Mysql', option='host'),
    'port': conf.get(section='Mysql', option='port'),
    'minsize': conf.get(section='Mysql', option='minsize'),
    'maxsize': conf.get(section='Mysql', option='maxsize'),

}

db_util = mysql_connecter(db_cfg=mysql_config)
db_util.set_transaction_isolation_read_committed()
#lock_db_util = mysql_connecter(db_cfg=mysql_config)


imr_mysql_config = {
    'user': conf.get(section='Mysqlimr', option='user'),
    'password': conf.get(section='Mysqlimr', option='password'),
    'db': conf.get(section='Mysqlimr', option='db'),
    'host': conf.get(section='Mysqlimr', option='host'),
    'port': conf.get(section='Mysqlimr', option='port'),
    'minsize': conf.get(section='Mysqlimr', option='minsize'),
    'maxsize': conf.get(section='Mysqlimr', option='maxsize'),

}

imr_db_util = mysql_connecter(db_cfg=imr_mysql_config)
imr_db_util.check_connect()
imr_db_util.set_transaction_isolation_read_committed()


mon_mysql_config = {
    'user': conf.get(section='Mysqlmon', option='user'),
    'password': conf.get(section='Mysqlmon', option='password'),
    'db': conf.get(section='Mysqlmon', option='db'),
    'host': conf.get(section='Mysqlmon', option='host'),
    'port': conf.get(section='Mysqlmon', option='port'),
    'minsize': conf.get(section='Mysqlmon', option='minsize'),
    'maxsize': conf.get(section='Mysqlmon', option='maxsize'),

}

mon_db_util = mysql_connecter(db_cfg=mon_mysql_config)
mon_db_util.check_connect()
mon_db_util.set_transaction_isolation_read_committed()



root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


mysql_log_loop = AsyncMysqlThreadLoop(conf=mysql_config)
mysql_ailog_loop = AsyncMysqlThreadLoop(conf=mysql_config)

func_loop=AsyncThreadLoop()

try:
    dir_name = conf.get(section='logging', option='dir')
except:
    dir_name = 'log'
log_path = os.path.join(root_path, dir_name)


NODE = conf.get('global','node')

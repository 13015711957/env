# -*- coding: utf-8 -*-

'''
@project : AI_ControlServer
@FileName: __init__.py
@Desc  :
'''

import os
import sys

import Core.sys_code_config as SYS_CODE
from Core.config_util import ConfigUtil
from Core.mysql_connecter import mysql_connecter
from Core.pgsql_connecter import pgsql_connecter
from Core.AsyncThreadLoop import AsyncThreadLoop
from Core.AsyncMysqlLoop import AsyncMysqlThreadLoop

__all__ = ['conf', 'db_util', 'SYS_CODE', 'root_path', 'log_path']

config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if os.path.exists(r'/project/config.ini'):
    config_path = r'/project/'

print("config_path: ", config_path)
try:
    conf = ConfigUtil(config_path=os.path.join(config_path, 'config.ini'))
except Exception as e:
    print('config read error : {}'.format(e))

time_config = {
    'stand_time': conf.get(section='time_second', option='stand_time'),
    'elapsed_time': conf.get(section='time_second', option='elapsed_time')
}

pgsql_config = {
    'user': conf.get(section='Pgsql', option='user'),
    'password': conf.get(section='Pgsql', option='password'),
    'db': conf.get(section='Pgsql', option='db'),
    'host': conf.get(section='Pgsql', option='host'),
    'port': conf.get(section='Pgsql', option='port'),
    'minsize': conf.get(section='Pgsql', option='minsize'),
    'maxsize': conf.get(section='Pgsql', option='maxsize'),

}
db_mode = conf.get(section='Pgsql', option='db_mode')

db_util = pgsql_connecter(db_cfg=pgsql_config, db_mode=db_mode)
imr_db_util = pgsql_connecter(db_cfg=pgsql_config, db_mode=db_mode)

root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

try:
    dir_name = conf.get(section='logging', option='dir')
except:
    dir_name = 'log'
log_path = os.path.join(root_path, dir_name)

NODE = conf.get('global', 'node')

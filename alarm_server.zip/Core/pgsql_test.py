import psycopg2
 
try:
   connection = psycopg2.connect(user="postgres",
                                  password="postgres#@2o2!",
                                  host="10.143.165.93",
                                  port="5432",
                                  database="room")
   cursor = connection.cursor()
   postgreSQL_select_Query = "select roomid, camera_id from rack where name = 'B-16'"
 
   cursor.execute(postgreSQL_select_Query)
   mobile_records = cursor.fetchall() 
   print(mobile_records) 
 
except (Exception, psycopg2.Error) as error :
    print ("Error while fetching data from PostgreSQL", error)
 
finally:
    #closing database connection.
    if(connection):
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

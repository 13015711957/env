# -*- encoding: utf-8 -*-
"""
@FileName ：img_track_plt.py
@Time ： 2021/5/12 18:04
@Auth ： Ying
"""

import Ability.FairMot.visualization as vis
import cv2
import numpy as np

def plt_track(track):
    # plt track
    img0 = track['img']
    frame_id = track['frame_id']
    tlwhs = []
    track_ids = []
    scores = []
    for item in track.get('data'):
        tlwhs.append(np.array(item['bbox']))
        track_ids.append(item['object_id'])
        #track_ids.append('{}-{}'.format(item['object_id'],item['id']))
        scores.append(item['score'])

    online_im = vis.plot_tracking(img0,tlwhs,track_ids,frame_id=frame_id,fps=0)
    #cv2.imwrite(os.path.join(frame_dir, '{:05d}.jpg'.format(frame_id)),online_im)

    return online_im

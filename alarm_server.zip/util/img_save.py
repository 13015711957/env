import cv2
import uuid
import os


def save_img(img_array):
    if not img_array.tolist():
        return '', ''
    img_uid = str(uuid.uuid5(uuid.uuid4(), 'save_img'))
    # save_path = os.path.abspath(__file__).split('VideoAnalysisProject')[0] + 'pictures/' + img_uid + '.jpg'
    save_path = '/home/AI_Marked/' + img_uid + '.jpg'
    cv2.imwrite(save_path, img_array)

    return img_uid, save_path
# -*- coding: utf-8 -*-

'''
@project : publicOpinionAnalysis_V2
@FileName: time_util
@Author  :linych 
@Time    :2020/8/22 17:01
@Desc  : 
'''


import datetime
from functools import wraps
import time


def get_now_time():
    '''
    获取当前时间字符串 %Y-%m-%d %H:%M:%S
    :return:  str
    '''

    now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    return now_str


def formatGMTime(timestamp):
    GMT_FORMAT = '%a, %d %b %Y %H:%M:%S GMT'
    # a = datetime.datetime.strptime(timestamp, GMT_FORMAT) + datetime.timedelta(hours=8)
    a = datetime.datetime.strptime(timestamp, GMT_FORMAT)
    return a


def use_time(func):
    @wraps(func)
    def wrap(*args, **kwargs):
        start = time.time()
        res = func(*args, **kwargs)
        end = time.time()
        print('#FUN(%s) Use time=[%s]'%(func.__name__, end-start))
        return res
    return wrap

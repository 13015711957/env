
# -*- coding: utf-8 -*-


from functools import wraps
import time
import numpy as np
import json
from prometheus_client import Counter
from prometheus_client import CollectorRegistry ,generate_latest,multiprocess

registry = CollectorRegistry()
multiprocess.MultiProcessCollector(registry)


# counter：一种累加的metric，如请求的个数，结束的任务数，出现的错误数等
counter = Counter('ai_api_request','api请求数量',['project','uri'])
counter_success = Counter('ai_api_request_success','api请求成功数量',['project','uri'])
counter_error = Counter('ai_api_request_error','api请求错误数量',['project','uri'])
counter_use_time = Counter('ai_api_request_use_time','api请求耗时',['project','uri'])

def prometheus_util(project,success_code,code_name='code',name='func',):
    success_code = np.array([success_code]).reshape(-1).tolist()

    def call(func):
        @wraps(func)
        async def wraper(*args,**kwargs):
            try:
                start = time.time()

                counter.labels(project,name).inc(1)  # Increment by 1

                res = await func(*args, **kwargs)

                res_copy = res

                try:
                    if isinstance(res_copy,dict):
                        res_copy = res_copy
                    else:
                        res_copy = json.loads(res_copy)
                    if res_copy[code_name] not in success_code:
                        counter_error.labels(project,name).inc(1)  # Increment by 1
                    else:
                        counter_success.labels(project,name).inc(1)  # Increment by 1
                except Exception as e:
                    print(e)
                end = time.time()

                counter_use_time.labels(project,name).inc(end-start)

                return res
            except Exception as e:
                print('Error {} reson: {}'.format(func.__name__,e))
                counter_error.labels(project,name).inc(1)  # Increment by 1
                raise e

        return wraper
    return call



async def metricHandle():
    return generate_latest(registry)

# -*- coding: utf-8 -*-

'''
@project : address_analysis
@FileName: new_id
@Author  :linych 
@Time    :2020/4/27 22:12
@Desc  : 
'''

import uuid


def new_id():
    cid = uuid.uuid1()
    return cid

if __name__ == '__main__':
    uid = new_id()
    print(uid)
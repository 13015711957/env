# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: iou_util
@Author  :linych 
@Time    :2020/12/11 11:12
@Desc  : 
'''





def compute_IOU(rec1,rec2):
    """
    计算两个矩形框的交并比。
    :param rec1: [x0,y0,W,H]      (x0,y0)代表矩形左上的顶点，（x1,y1）代表矩形右下的顶点。下同。
    :param rec2: [x0,y0,W,H]
    :return: 交并比IOU.
    """

    rec1[2] += rec1[0]
    rec1[3] += rec1[1]
    print(rec1)
    rec2[2] += rec2[0]
    rec2[3] += rec2[1]
    print(rec2)

    left_column_max  = max(rec1[0],rec2[0])
    right_column_min = min(rec1[2],rec2[2])
    up_row_max       = max(rec1[1],rec2[1])
    down_row_min     = min(rec1[3],rec2[3])

    #两矩形无相交区域的情况
    if left_column_max>=right_column_min or down_row_min<=up_row_max:
        return 0
    # 两矩形有相交区域的情况
    else:
        S1 = (rec1[2]-rec1[0])*(rec1[3]-rec1[1])
        S2 = (rec2[2]-rec2[0])*(rec2[3]-rec2[1])
        S_cross = (down_row_min-up_row_max)*(right_column_min-left_column_max)
        return S_cross / (S1 + S2 - S_cross)


def cal_iou(box1, box2):
    """
    :param box1: = [xmin1, ymin1, xmax1, ymax1]
    :param box2: = [xmin2, ymin2, xmax2, ymax2]
    :return:
    """
    box1[2] += box1[0]
    box1[3] += box1[1]
    box2[2] += box2[0]
    box2[3] += box2[1]
    
    xmin1, ymin1, xmax1, ymax1 = box1
    xmin2, ymin2, xmax2, ymax2 = box2
    # 计算每个矩形的面积
    s1 = (xmax1 - xmin1) * (ymax1 - ymin1)  # b1的面积
    s2 = (xmax2 - xmin2) * (ymax2 - ymin2)  # b2的面积

    # 计算相交矩形
    xmin = max(xmin1, xmin2)
    ymin = max(ymin1, ymin2)
    xmax = min(xmax1, xmax2)
    ymax = min(ymax1, ymax2)

    w = max(0, xmax - xmin)
    h = max(0, ymax - ymin)
    a1 = w * h  # C∩G的面积
    a2 = s1 + s2 - a1
    #iou = a1 / a2  # iou = a1/ (s1 + s2 - a1)
    iou = a1 / s2       #计算物品面积占比
    return iou

def list_of_groups(list_info, per_list_len):
    '''
    :param list_info:   列表
    :param per_list_len:  每个小列表的长度
    :return:
    '''
    list_of_group = zip(*(iter(list_info),) *per_list_len)
    end_list = [list(i) for i in list_of_group] # i is a tuple
    count = len(list_info) % per_list_len
    end_list.append(list_info[-count:]) if count !=0 else end_list
    return end_list


if __name__ == '__main__':

    #测试样例1
    r1=(2,3,10,12)
    r2=(12,5,20,24)
    IOU = compute_IOU(r1,r2)
    print("测试样例1，IOU：%f"%IOU)
    #测试样例2
    r1=(2,2,4,4)
    r2=(3,3,5,5)
    IOU = compute_IOU(r1,r2)
    print("测试样例2，IOU：%f"%IOU)



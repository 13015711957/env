# import os
# import sys
#
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# import base64
# import numpy as np
#
# import cv2
# import numpy as np
#
#
# def img_cut(image_base64,bbox):
#     base64Image = image_base64.replace("%2B", "+").replace("%3D", "=").replace("%2F", "/")
#     img = base64.b64decode(base64Image)
#     img_array = np.fromstring(img, np.uint8)
#     img_array = img_array.reshape((720, 1280, 3))
#     ori_img = img_array
#     # cv2.imwrite("/home/face/projects/SmartHomeVideo/temp/be_cutface.jpg", ori_img)
#
#     ori_img = ori_img[max(0, int(bbox[1])):min(int(bbox[1]+bbox[3]), ori_img.shape[0]),
#                       max(0, int(bbox[0])):min(int(bbox[0]+bbox[2]), ori_img.shape[1])]  # x, y, w, h
#
#     image_base64 = cv2.imencode('.jpg', img_array)[1].tostring()
#     image_base64 = base64.b64encode(image_base64)
#     image_base64 = str(image_base64)[2:-1]
#     # cv2.imwrite("/home/face/projects/SmartHomeVideo/temp/cutface.jpg",ori_img)
#     return image_base64, ori_img

import base64
import numpy as np
import cv2


def img_resize(img):
    h, w, c = img.shape
    if h > 300 or w > 300:
        h_scale = 300
        w_scale = int(h_scale / h * w)
        img = cv2.resize(img, (w_scale, h_scale))
    return img


def img_cut(img_array, bbox):
    img_array = img_array[max(0, int(bbox[1])):min(int(bbox[1] + bbox[3]), img_array.shape[0]),
                max(0, int(bbox[0])):min(int(bbox[0] + bbox[2]), img_array.shape[1])]
    return img_array


def img_to_base64(img_path):
    img = cv2.imread(img_path)
    pic_str = base64.b64encode(img)
    pic_str = pic_str.decode()
    # retval, buffer = cv2.imencode('.jpg', img)
    # jpg_as_text = base64.b64encode(buffer)
    # b64_code = jpg_as_text.decode('utf-8')
    return pic_str


def array_to_base64(img_array):
    retval, buffer = cv2.imencode('.jpg', img_array)
    pic_str = base64.b64encode(buffer)
    pic_str = pic_str.decode()
    return pic_str


def base64_to_array(img_base64, size=None):
    img_data = base64.b64decode(img_base64)
    nparr = np.fromstring(img_data, np.uint8)
    if size:
        img_np = nparr.reshape(size)
        return img_np
    img_np = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img_np


def img_cut_resize(img_array, bbox, cut_prob):
    img_array = img_array[
                max(0, int(bbox[1] - bbox[3] * cut_prob)):min(int(bbox[1] + bbox[3] * (1 + cut_prob)),
                                                              img_array.shape[0]),
                max(0, int(bbox[0] - bbox[2] * cut_prob)):min(int(bbox[0] + bbox[2] * (1 + cut_prob)),
                                                              img_array.shape[1])]
    return img_array


if __name__ == '__main__':
    img_path = r'F:\zqx_work\project\test[459.1427917480469, 130.750244140625, 347.3904113769531, 644.6961669921875].jpg'

    img_array = cv2.imread(img_path)
    cut_img_array = img_cut(img_array, [459.1427917480469, 130.750244140625, 347.3904113769531, 644.6961669921875])

    img_base64 = array_to_base64(cut_img_array)

    img_array = base64_to_array(img_base64, [720, 1280, 3])

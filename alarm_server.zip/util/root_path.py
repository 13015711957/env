


import os

def get_root_path():

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    return root


if __name__ == '__main__':

    print(get_root_path())

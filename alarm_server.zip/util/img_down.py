# -*- coding: utf-8 -*-

'''
@project : AIGateWay
@FileName: img_down
@Author  :linych 
@Time    :2020/11/26 16:23
@Desc  : 
'''

import base64
from io import BytesIO
from Client.asyn_request import AsynClient
import aiohttp
import json
import time
import ailog

asynClient = AsynClient()
url =  'http://10.128.86.64:8000/serviceAgent/rest/public_Opinion_API/InquireHotSpot'
header = {
    'Content-type': 'application/json',
    'X-APP-ID':'9c04c3e9cf25da44f4220a8efbab839d',
    'X-APP-KEY':'f885de544a8eddd4185f95b2a2b13350'

}


async def img_download(seqid,img_url):

    #data = {'seqid':seqid,'fileUrl':img_url}
    #data  =json.dumps(data)
    #response = await asynClient.post(url=url,body=data,header=header) # 将这个图片保存在内存

    #response = json.loads(response)
    #img_base64 = response['data']['image']
    s = time.time()
    async with aiohttp.request('GET', img_url,proxy='http://10.143.165.150:7001') as resp:
        r = await resp.content.read()
        r = base64.b64encode(r)
        r = str(r)
        img_base64 = r[2:-1]

    ailog.info('img_down {} {}'.format(time.time()-s,len(img_base64)))


    return img_base64


if __name__ == '__main__':


    async def run():
        url = 'https://tyai-000000-365t.jxoss.xstore.ctyun.cn/1F9B038F10/2020/11/26/20201126141744-ALARM.jpg'

        t = await img_download(url)

        print(t)

        return t

    import asyncio
    loop = asyncio.get_event_loop()
    task = [asyncio.ensure_future(run())]

    loop.run_until_complete(asyncio.wait(task))


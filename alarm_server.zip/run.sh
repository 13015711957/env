#!/bin/bash
./run.sh restart